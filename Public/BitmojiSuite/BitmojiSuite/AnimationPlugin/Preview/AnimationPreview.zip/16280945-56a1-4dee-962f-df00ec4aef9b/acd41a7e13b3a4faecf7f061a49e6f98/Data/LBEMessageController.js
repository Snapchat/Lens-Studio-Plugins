//@input SceneObject animParent
//@input Component.ScriptComponent clothComponent
//@input Asset.AnimationAsset defaultAnimAsset

var bitmoji3DComponent = script.animParent.getComponent("Component.ScriptComponent");
var localAnimPlayer = script.animParent.getComponent("Component.AnimationPlayer");
var transformData = [];

init();

function init() {
    script.clothComponent.addOnDownloadedCallback(() => {
        transformData = [];
        getTransformData(script.animParent)
    })
}

script.createEvent("MessageEvent").bind((event) => {
    if (event.data.event_type == "update_outfit") {
        const params = event.data.params;
        if (params) {
            script.clothComponent.updateClothes(JSON.parse(params).items, event.data.bitmojiType, event.data.friendIndex);
        }
        return;
    }
    
    if (event.data.event_type == "reset_animation") {    
        resetAnimations();
        return;
    }
    
    if (event.data.event_type == "update_animation") {
        const path = event.data.path;
        var obj = Editor.importFbx(path);
    
        var animPlayer = obj.getComponent("Component.AnimationPlayer");
        var clip = animPlayer.clips[0];
        
        var localAnimPlayer = script.animParent.getComponent("Component.AnimationPlayer");
        if (localAnimPlayer.clips.length > 0) {
            localAnimPlayer.removeClip(localAnimPlayer.clips[0].name)
            localAnimPlayer.forceUpdate(0);
        }
        resetBlendShapes(script.animParent);
        setTransformData();
        clip.begin = 0.0333;
        localAnimPlayer.addClip(clip);
        localAnimPlayer.playAll();
        localAnimPlayer.forceUpdate(0);
        obj.destroy();
        
        if (event.data.type == "video") {
            script.animParent.getTransform().setWorldPosition(new vec3(0, 60, 200));
        }
        else {
            script.animParent.getTransform().setWorldPosition(new vec3(0, 0, 0));
        }
        
        return;
    }
})

function resetAnimations() {
    var clip = localAnimPlayer.clips[0];
    clip.animation = script.defaultAnimAsset;
    clip.end = script.defaultAnimAsset.duration;

    resetBlendShapes(script.animParent);
    setTransformData();

    localAnimPlayer.playAll();
    localAnimPlayer.forceUpdate(0);
}

function resetBlendShapes(obj) {
    if (obj.name === "C_brow_GEO" || obj.name === "C_head_GEO" || obj.name === "universal_head_eyelash_GEO") {
        var renderMeshVisual = obj.getComponent("Component.RenderMeshVisual");
        if (renderMeshVisual && renderMeshVisual.blendShapesEnabled) {
            var blendShapeNames = renderMeshVisual.getBlendShapeNames();
            blendShapeNames.forEach(function(name) {
                obj.getComponent("Component.RenderMeshVisual").setBlendShapeWeight(name, 0);
            })
        }
    }
    
    for (var i = 0; i < obj.getChildrenCount(); i++) {
        resetBlendShapes(obj.getChild(i));
    }
}

function getTransformData(obj) {
    var transform = obj.getTransform();
    transformData.push({transform : transform, localPosition : transform.getLocalPosition(), localRotation : transform.getLocalRotation(), localScale : transform.getLocalScale()})
    
    for (var i = 0; i < obj.getChildrenCount(); i++) {
        getTransformData(obj.getChild(i));
    }
}

function setTransformData() {
    transformData.forEach(function(data) {
        data.transform.setLocalPosition(data.localPosition);
        data.transform.setLocalRotation(data.localRotation);
        data.transform.setLocalScale(data.localScale);
    })
}