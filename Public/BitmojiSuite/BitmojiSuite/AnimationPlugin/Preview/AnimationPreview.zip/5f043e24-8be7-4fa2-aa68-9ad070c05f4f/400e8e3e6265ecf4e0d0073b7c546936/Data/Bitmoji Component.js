const remoteMediaModule = require('LensStudio:RemoteMediaModule');
const bitmojiModule = require('LensStudio:BitmojiModule');

// @input Asset.Material material

// Bitmoji Download {

async function getBitmojiResource(options) {
    return new Promise(function (resolve, reject) {
        bitmojiModule.requestBitmoji3DResourceWithOptions(options, resolve);
    });
}

async function download3DAsset(bitmoji3DResource) {
    return new Promise(function (resolve, reject) {
        remoteMediaModule.loadResourceAsGltfAsset(
            bitmoji3DResource,
            resolve,
            reject
        );
    });
}

async function instantiateGLTFAsset(gltfAsset) {
    return new Promise((resolve, reject) => {
        let settings = GltfSettings.create();
        settings.convertMetersToCentimeters = true;
        settings.optimizeGeometry = true;
        settings.storeTriangleOrder = true;

        gltfAsset.tryInstantiateAsync(
            script.getSceneObject(),
            script.material,
            (avatar) => {
                resolve({ avatar, extras: gltfAsset.extras });
            },
            (error) => {
                reject(error);
            },
            () => {

            },
            settings
        );
    });
}

// } Bitmoji Download


script.fixLayers = () => {
    const traverse = (so, renderLayer) => {
        so.layer = renderLayer;

        const rmv = so.getComponent("RenderMeshVisual");
        if (rmv) {
            rmv.meshShadowMode = MeshShadowMode.Caster;
        };

        so.children.forEach((child) => {
           traverse(child, renderLayer);
        });
    }

    traverse(script.avatar, script.getSceneObject().layer);
}

const setAvatar = (avatar) => {
    avatar.setParent(script.getSceneObject());

    onAvatarUpdated(script.avatar);

    script.oldAvatar = script.avatar;

    script.avatar = avatar;
    script.fixLayers();
}

script.bitmojiType = null;
script.friendIndex = -1;

script.setUser = async (type, friendIndex = -1, parametersList) => {
    /*
    if (!isSameUser(type, friendIndex)) {
        if (script.avatar) {
            script.avatar.destroy();
            script.avatar = null;
        }
    }
    */

    script.currentUser = await getUser(type, friendIndex);
    await script.refreshBitmoji(script.currentUser, parametersList);

    if (!isSameUser(type, friendIndex)) {
        if (script.avatar) {
            script.avatar.enabled = false;
        }
    }

    script.bitmojiType = type;
    script.friendIndex = friendIndex;

    return script.getAvatar();
}

script.getUser = () => {
    return script.currentUser;
}

script.getAvatar = () => {
    return script.avatar;
}

const setExtras = (extras) => {
    script.extras = extras;
}

script.getExtras = () => {
    return script.extras;
}

script.enable = () => {
    if (script.avatar) {
        if (script.oldAvatar) {
            script.oldAvatar.destroy();
            script.oldAvatar = null;
        }
        script.avatar.enabled = true;
    }
}

script.refreshBitmoji = async (user, parametersList) => {
    if (!user) {
        return;
    }

    let options = Bitmoji3DOptions.create();
    options.user = user;
    options = modifyBitmoji3DOptions(options, parametersList);

    const bitmoji3DResource = await getBitmojiResource(options);
    const gltfAsset = await download3DAsset(bitmoji3DResource);
    const { avatar, extras } = await instantiateGLTFAsset(gltfAsset);
    avatar.enabled = false;

    setExtras(extras);
    setAvatar(avatar);
}

// download bitmoji in split-clothing format
const modifyBitmoji3DOptions = (options, parametersList) => {
    parametersList = parametersList.filter((params) => params.type != "glasses");
    if (parametersList.length == 0) {
        return options;
    }

    var customParams = options.customParams;
    if (!customParams) {
        customParams = Bitmoji3DOptions.CustomParams.create();
    }

    customParams.clothingType = Bitmoji3DOptions.ClothingType.SplitClothes;

    const footwear = parametersList.find((params) => params.type == "footwear" || params.type == "footWear");

    if (footwear) {
        var params = Bitmoji3DOptions.ParamSet.create();

        params.optionId = footwear.optionId;

        if (footwear.params) {
            params.params = JSON.parse(footwear.params);
        }
        customParams.footWear = params;
    }

    options.customParams = customParams;
    options.requestType = Bitmoji3DOptions.RequestType.Custom;

    return options;
}

const pendingRequestsForBitmoji = [];

const onAvatarUpdated = async (avatar) => {
    pendingRequestsForBitmoji.forEach(async (cb) => {
        await cb(avatar);
    });

    pendingRequestsForBitmoji.length = 0;
}

script.waitForBitmoji = (cb) => {
    if (script.avatar) {
        cb(script.avatar);
    } else {
        pendingRequestsForBitmoji.push(cb);
    }
}

function isSameUser(bitmojiType, friendIndex) {
    if (script.bitmojiType != null) {
        switch(bitmojiType) {
            case 1:
                // friend, check friend index is equal
                return script.bitmojiType == bitmojiType && script.friendIndex == script.friendIndex;
            case 2:
                // my ai
                return script.bitmojiType == bitmojiType;
            default:
                // anything else, check that current bitmoji isn't friend or my ai
                return script.bitmojiType != 1 && script.bitmojiType != 2;
        }
    } else {
        return false;
    }
}

async function getUser(bitmojiType, friendIndex) {
    switch(bitmojiType) {
        case 1:
            // friend
            return new Promise((resolve) => {
                global.userContextSystem.getAllFriends((users) => {
                    if (!friendIndex) {
                        friendIndex = 0;
                    }
                    const friend = users[friendIndex % users.length];
                    resolve(friend);
                });
            });
        case 2:
            // my ai
            return new Promise((resolve) => {
                global.userContextSystem.getMyAIUser((user) => {
                    resolve(user);
                });
            });
        default:
            // current user
            return new Promise((resolve) => {
                global.userContextSystem.getCurrentUser((user) => {
                    resolve(user);
                });
            });
    }
}
