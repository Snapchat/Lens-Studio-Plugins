const remoteMediaModule = require('LensStudio:RemoteMediaModule');
const bitmojiModule = require('LensStudio:BitmojiModule');

// @input Asset.Material material
// @input Component.ScriptComponent bitmoji

const fixType = {
    "bottom": "bottomWear",
    "bottomwear": "bottomWear",
    "footwear": "footWear",
    "outerwear": "outerWear"
}

script.bitmojiData = null;

let bitmojiSo = null;
let onDownloadedCallback = [];

const traverse = (so, renderLayer) => {
    so.layer = renderLayer;

    const rmv = so.getComponent("RenderMeshVisual");
    if (rmv) {
        rmv.meshShadowMode = MeshShadowMode.Caster;
    };

    so.children.forEach((child) => {
       traverse(child, renderLayer);
    });
}

const pendingRequestsForBitmojiData = [];

script.requestBitmojiData = (cb) => {
    if (script.bitmojiData) {
        cb(script.bitmojiData);
    } else {
        pendingRequestsForBitmojiData.push(cb);
    }
}

function setBitmojiData(data) {
    script.bitmojiData = data;
    pendingRequestsForBitmojiData.forEach((cb) => cb(script.bitmojiData));
}

function createBitmojiData(extras) {
    extras = JSON.parse(extras);

    return {
        bodyType: extras.bodyType,
        breastType: extras.breastType,
        gender: extras.gender == "male" ? 1 : 2,
    }
}

script.glassesSo = null;
script.clothesSo = null;

script.updateClothes = async (outfitOverrideParameters, bitmojiType, friendIndex) => {
    try {
        if (Editor && Editor.context) {
            Editor.context.postMessage({
                "event_type": "onBusyChanged",
                "event_value": true
            });
        }

        script.bitmojiData = null;
        bitmojiAvatar = await script.bitmoji.setUser(bitmojiType, friendIndex, outfitOverrideParameters);
        setBitmojiData(createBitmojiData(script.bitmoji.getExtras()));

        const user = script.bitmoji.getUser();

        const glassesPromise = downloadBitmojiParts(user, true, outfitOverrideParameters);
        const clothesPromise = downloadBitmojiParts(user, false, outfitOverrideParameters);

        Promise.all([glassesPromise, clothesPromise]).then(([glassesResult, clothesResult]) => {
            if (glassesResult.clothes) {
                processClothes(script.bitmoji, glassesResult.clothes, glassesResult.extras, ["universal_head_glasses_GRP"], false);
                if (script.glassesSo) {
                    script.glassesSo.destroy();
                }
                script.glassesSo = glassesResult.clothes;
            } else {
                const glasses = outfitOverrideParameters.find((params) => params.type == "glasses");
                if (glasses && glasses.optionId == "") {
                    const glassesObj = findByName(script.bitmoji.getAvatar(), "universal_head_glasses_GRP");
                    if (glassesObj) {
                        glassesObj.destroy();
                    }
                }
            }

            if (clothesResult.clothes) {
                processClothes(script.bitmoji, clothesResult.clothes, clothesResult.extras, ["clothes_GRP"], true);
                if (script.clothesSo) {
                    script.clothesSo.destroy();
                }
                script.clothesSo = clothesResult.clothes;
            }

            script.bitmoji.fixLayers();
            script.bitmoji.enable(true);

            onDownloadedCallback.forEach(function(cb) {
                cb();
            });

            if (Editor && Editor.context) {
                Editor.context.postMessage({
                    "event_type": "onBusyChanged",
                    "event_value": false
                });
            }
        }).catch((error) => {
            print(error.message);
        });
    } catch(error) {
        print(error.message);
        print(error.stack);
    }
}

script.addOnDownloadedCallback = (callback) => {
    onDownloadedCallback.push(callback);
}

async function downloadBitmojiParts(user, isGlasses = false, parametersList) {
    let options = Bitmoji3DOptions.create();
    options.user = user;

    if (isGlasses) {
        const glasses = parametersList.find((params) => params.type == "glasses");
        if (glasses && glasses.optionId) {
            options = addGlassesToOptions(options, glasses.optionId);
        } else {
            return { clothes: null, extras: null };
        }
    } else {
        filteredList = parametersList.filter((params) => params.type != "glasses");
        if (filteredList.length > 0) {
            parametersList.forEach((params) => {
                options = modifyOptions(options, params);
            });
        } else {
            return { clothes: null, extras: null }
        }
    }

    const bitmoji3DResource = await getBitmojiResource(options);
    const gltfAsset = await download3DAsset(bitmoji3DResource);
    return await instantiateGLTFAsset(gltfAsset);
}

const addGlassesToOptions = (options, optionId) => {
    var customParams = options.customParams;
    if (!customParams) {
        customParams = Bitmoji3DOptions.CustomParams.create();
    }

    customParams.clothingType = Bitmoji3DOptions.ClothingType.SplitClothes;
    customParams.avatarScope = Bitmoji3DOptions.AvatarScope.Glasses;

    customParams["glasses"] = optionId;

    options.customParams = customParams;
    options.requestType = Bitmoji3DOptions.RequestType.Custom;

    return options;
}

const modifyOptions = (options, args) => {
    // ignore glasses, download them in separate request
    if (args.type == "glasses") {
        return options;
    }

    var customParams = options.customParams;
    if (!customParams) {
        customParams = Bitmoji3DOptions.CustomParams.create();
    }

    customParams.clothingType = Bitmoji3DOptions.ClothingType.SplitClothes;
    customParams.avatarScope = Bitmoji3DOptions.AvatarScope.Clothes;

    var params = Bitmoji3DOptions.ParamSet.create();

    params.optionId = args.optionId;
    if (args.params) {
        params.params = JSON.parse(args.params);
    }

    if (args.type in fixType) {
        args.type = fixType[args.type];
    }

    customParams[args.type] = params;

    options.customParams = customParams;
    options.requestType = Bitmoji3DOptions.RequestType.Custom;

    return options;
}

function processClothes(bitmoji, clothes, extras, nodeGroupNames, clearFaces) {
    const bitmojiAvatar = bitmoji.getAvatar();
    const bitmojiExtras = JSON.parse(bitmoji.getExtras());

    patchNodes(clothes, bitmojiAvatar, nodeGroupNames);
    remapSkinBones(clothes, bitmojiAvatar);

    extras = JSON.parse(extras);

    if (clearFaces) {
        facesCleanup(bitmojiAvatar, bitmojiExtras, extras);
    }
}

// Bitmoji Download {

async function getBitmojiResource(options) {
    return new Promise(function (resolve, reject) {
        bitmojiModule.requestBitmoji3DResourceWithOptions(options, resolve);
    });
}

async function download3DAsset(bitmoji3DResource) {
    return new Promise(function (resolve, reject) {
        remoteMediaModule.loadResourceAsGltfAsset(
            bitmoji3DResource,
            resolve,
            reject
        );
    });
}

async function instantiateGLTFAsset(gltfAsset) {
    return new Promise((resolve, reject) => {
        let settings = GltfSettings.create();
        settings.convertMetersToCentimeters = true;
        settings.optimizeGeometry = true;
        settings.storeTriangleOrder = true;
        gltfAsset.tryInstantiateAsync(
            script.getSceneObject(),
            script.material,
            (avatar) => {
                avatar.enabled = false;
                resolve({ clothes: avatar, extras: gltfAsset.extras });
            },
            (error) => {
                reject(error);
            },
            () => {

            },
            settings
        );
    });
}

// } Bitmoji Download

// Cloths Post-Processing {

const facesCleanup = (bitmojiAvatar, bitmojiExtras, clothesExtras) => {
    const facesToDelete = new Set(
        clothesExtras.bodyFacesToDelete || []
    );

    const avatarBodyEntity = findSceneObjectInHierarchy(
        bitmojiAvatar,
        (sceneObject) => sceneObject.name === "body_GEO"
    );

    const bodyMesh =
        avatarBodyEntity.getComponent("RenderMeshVisual").mesh;

    const bodyIndices = bodyMesh.extractIndices();

    const bodyTriangleOrder = bitmojiExtras.triangleOrder ? bitmojiExtras.triangleOrder[bodyMesh.name] : undefined;

    const newBodyIndices = [];
    const numFaces = bodyIndices.length / 3;
    for (let faceId = 0; faceId < numFaces; faceId++) {
        const originalFaceId = bodyTriangleOrder ? bodyTriangleOrder[faceId] : faceId;

       if (facesToDelete.has(originalFaceId)) {
            newBodyIndices.push(0);
            newBodyIndices.push(0);
            newBodyIndices.push(0);
        } else {
            newBodyIndices.push(bodyIndices[faceId * 3]);
            newBodyIndices.push(bodyIndices[faceId * 3 + 1]);
            newBodyIndices.push(bodyIndices[faceId * 3 + 2]);
        }
    }

    const meshBuilder = MeshBuilder.createFromMesh(bodyMesh);

    meshBuilder.eraseIndices(0, meshBuilder.getIndicesCount());
    meshBuilder.appendIndices(newBodyIndices);

    avatarBodyEntity.getComponent("RenderMeshVisual").mesh = meshBuilder.getMesh();

    meshBuilder.updateMesh();
}

const remapSkinBones = (patchSceneObject, avatarSceneObject) => {
    const patchSkinNode = findSceneObjectInHierarchy(
        patchSceneObject,
        (sceneObject) => {
            return !!sceneObject.getComponent("Skin");
        }
    );
    const avatarSkinNode = findSceneObjectInHierarchy(
        avatarSceneObject,
        (sceneObject) => {
            return !!sceneObject.getComponent("Skin");
        }
    );

    if (!patchSkinNode || !avatarSkinNode) {
        const errorMessage = "Skin node not found in patch or avatar";
        //print(errorMessage);
        throw new Error(errorMessage);
    }
    const patchSkin = patchSkinNode.getComponent("Skin");
    const avatarSkin = avatarSkinNode.getComponent("Skin");
    //print(`Bones: ${patchSkin.getSkinBoneNames()}`);
    for (const boneName of patchSkin.getSkinBoneNames()) {
        const patchBone = patchSkin.getSkinBone(boneName);

        const avatarBoneNode = avatarSkin.getSkinBone(boneName);
        patchSkin.setSkinBone(boneName, avatarBoneNode);
    }

    avatarSkinNode.copyComponent(patchSkin);
};

const traverseFunc = (root, func) => {
    root.children.forEach((child) => {
        traverseFunc(child, func);
    });
    func(root);
}

const patchNodes = (
    patchSceneObject,
    avatarSceneObject,
    nodeGroupNames
) => {
    for (const nodeGroupName of nodeGroupNames) {
        //print(`Patch node group ${nodeGroupName}`);
        const patchGroupNode = findByName(patchSceneObject, nodeGroupName);
        const avatarGroupNode = findByName(avatarSceneObject, nodeGroupName);

        if (avatarGroupNode) {
            const parent = avatarGroupNode.getParent();
            if (!parent) {
                //print(`Avatar group node ${nodeGroupName} has no parent`);
                continue;
            }

            // Remove current group node
            //print(`Destroying old avatar group node ${nodeGroupName}`);
            avatarGroupNode.destroy();

            // Add new group node
            if (patchGroupNode) {
                // print(`Set patch group node ${nodeGroupName} parent to ${parent.name} in avatar scene object`);
                patchGroupNode.setParent(parent);
            }
        } else if (patchGroupNode) {
            const patchGroupNodeParent = patchGroupNode.getParent();
            if (!patchGroupNodeParent) {
                // print(`Patch group node ${nodeGroupName} has no parent`);
                continue;
            }
            const avatarNodeParent = findByName(
                avatarSceneObject,
                patchGroupNodeParent.name
            );
            if (!avatarNodeParent) {
                //print(`Avatar node parent ${patchGroupNodeParent.name} not found`);
                continue;
            }

            //print(`Adding new patch group to avatar ${nodeGroupName}`);
            patchGroupNode.setParent(avatarNodeParent);
        } else {
            //print(`No ${nodeGroupName} node group found in patch scene object or avatar scene object`);
        }
    }
};

// } Cloths Post-Processing

// Utils {

function findByName(node, name) {
    if (node.name === name) {
        return node;
    }
    for (const child of node.children) {
        const found = findByName(child, name);
        if (found) {
            return found;
        }
    }
    return undefined;
}

function findSceneObjectInHierarchy(node, predicate) {
    if (predicate(node)) {
        return node;
    }
    for (const child of node.children) {
        const found = findSceneObjectInHierarchy(child, predicate);
        if (found) {
            return found;
        }
    }
    return undefined;
}

// } Utils
