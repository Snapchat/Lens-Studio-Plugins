// @input Component.ScriptComponent bitmoji
// @input Component.ScriptComponent outfitOverride

script.bitmojiData = null;

let onDownloadedCallback = [];

const pendingRequestsForBitmojiData = [];

script.requestBitmojiData = (cb) => {
    if (script.bitmojiData) {
        cb(script.bitmojiData);
    } else {
        pendingRequestsForBitmojiData.push(cb);
    }
}

function setBitmojiData(data) {
    script.bitmojiData = data;
    pendingRequestsForBitmojiData.forEach((cb) => cb(script.bitmojiData));
}

function createBitmojiData(extras) {
    extras = JSON.parse(extras);

    return {
        bodyType: extras.bodyType,
        breastType: extras.breastType,
        gender: extras.gender == "male" ? 1 : 2,
    }
}

script.updateClothes = async (outfitOverrideParameters, bitmojiType, friendIndex) => {
    try {
        if (Editor && Editor.context) {
            Editor.context.postMessage({
                "event_type": "onBusyChanged",
                "event_value": true
            });
        }

        script.bitmojiData = null;
        bitmojiAvatar = await script.bitmoji.setUser(bitmojiType, friendIndex);
        setBitmojiData(createBitmojiData(script.bitmoji.getExtras()));

        script.outfitOverride.setOutfitOverrideParameters(outfitOverrideParameters);

        script.outfitOverride.modifyBitmoji3DAvatar(script.bitmoji).then(() => {
            onDownloadedCallback.forEach(function(cb) {
                cb();
            });

            if (Editor && Editor.context) {
                Editor.context.postMessage({
                    "event_type": "onBusyChanged",
                    "event_value": false
                });
            }
        }).catch((error) => {
            print(error.message);
            print(error.stack);
        });
    } catch(error) {
        print(error.message);
        print(error.stack);
    }
}

script.addOnDownloadedCallback = (callback) => {
    onDownloadedCallback.push(callback);
}
