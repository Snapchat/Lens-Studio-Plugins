﻿if (script.onAwake) {
    script.onAwake();
    return;
}
/*
@typedef OutfitType
@property {string} type = "mannequin-with-head-center" {"widget":"combobox", "values":[{"label":"Outfit", "value":"mannequin-with-head-center"}, {"label":"Top", "value":"top"}, {"label":"Bottom", "value":"bottom"}, {"label":"Dress", "value":"dress"}, {"label":"Footwear", "value":"footwear"}, {"label":"Bag", "value":"bag"}, {"label":"Outerwear", "value":"outerwear"}, {"label":"Glasses", "value":"glasses"}]}
*/
function checkUndefined(property, showIfData) {
    for (var i = 0; i < showIfData.length; i++) {
        if (showIfData[i][0] && script[showIfData[i][0]] != showIfData[i][1]) {
            return;
        }
    }
    if (script[property] == undefined) {
        throw new Error("Input " + property + " was not provided for the object " + script.getSceneObject().name);
    }
}
// @input string outfitOverrideParameters
// @input OutfitType[] outfitOverrideList
if (!global.BaseScriptComponent) {
    function BaseScriptComponent() {}
    global.BaseScriptComponent = BaseScriptComponent;
    global.BaseScriptComponent.prototype = Object.getPrototypeOf(script);
    global.BaseScriptComponent.prototype.__initialize = function () {};
    global.BaseScriptComponent.getTypeName = function () {
        throw new Error("Cannot get type name from the class, not decorated with @component");
    };
}
var Module = require("../../../../Modules/Src/Assets/Scripts/Outfit Override");
Object.setPrototypeOf(script, Module.OutfitOverride.prototype);
script.__initialize();
let awakeEvent = script.createEvent("OnAwakeEvent");
awakeEvent.bind(() => {
    checkUndefined("outfitOverrideParameters", []);
    checkUndefined("outfitOverrideList", []);
    if (script.onAwake) {
       script.onAwake();
    }
});
