"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OutfitOverride = exports.OutfitType = void 0;
var __selfType = requireType("./Outfit Override");
function component(target) {
    target.getTypeName = function () { return __selfType; };
    if (target.prototype.hasOwnProperty("getTypeName"))
        return;
    Object.defineProperty(target.prototype, "getTypeName", {
        value: function () { return __selfType; },
        configurable: true,
        writable: true
    });
}
const BAG_CATEGORY = "bag";
const BOTTOM_CATEGORY = "bottom";
const DRESS_CATEGORY = "dress";
const FOOTWEAR_CATEGORY = "footwear";
const GLASSES_CATEGORY = "glasses";
const OUTERWEAR_CATEGORY = "outerwear";
const OUTFIT_CATEGORY = "mannequin-with-head-center";
const SOCK_CATEGORY = "sock";
const TOP_CATEGORY = "top";
const GEO_GROUP_SUFFIX = "_GRP";
const GLASSES_GROUP_NAME = `universal_head_glasses${GEO_GROUP_SUFFIX}`;
const CLOTHES_GROUP_NAME = `clothes${GEO_GROUP_SUFFIX}`;
const BODY_GROUP_NAME = `body${GEO_GROUP_SUFFIX}`;
const BODY_GEO_NAME = "body_GEO";
const AVATAR_NAME = "AVATAR";
const DEFAULT_TOP_OPTION_ID = "10091326";
const DEFAULT_BOTTOM_OPTION_ID = "10091325";
const DEFAULT_FOOTWEAR_OPTION_ID = "10091327";
const DEFAULT_PARAMS = "{\"primary\":13882585,\"secondary\":13882585,\"tertiary\":13882585,\"quaternary\":13882585,\"buttons\":8674118,\"metal\":13882585,\"laces\":13882585,\"detail\":13882585,\"belt\":13882585,\"furtrim\":13882585}";
const DEFAULT_FOOTWEAR_PARAMS = "{\"primary\":16448250,\"secondary\":16448250,\"tertiary\":16448250,\"quaternary\":16448250,\"sole\":16448250,\"metal\":16448250,\"laces\":16448250,\"detail\":16448250,\"elastic\":16448250,\"furtrim\":16448250}";
var AlternativeBody;
(function (AlternativeBody) {
    AlternativeBody[AlternativeBody["DEFAULT"] = 0] = "DEFAULT";
    AlternativeBody[AlternativeBody["SOCK"] = 1] = "SOCK";
})(AlternativeBody || (AlternativeBody = {}));
var AvatarBodyType;
(function (AvatarBodyType) {
    AvatarBodyType["DEFAULT"] = "default";
    AvatarBodyType["HEAVY"] = "heavy";
})(AvatarBodyType || (AvatarBodyType = {}));
var Gender;
(function (Gender) {
    Gender["MALE"] = "male";
    Gender["FEMALE"] = "female";
})(Gender || (Gender = {}));
var BodyType;
(function (BodyType) {
    BodyType[BodyType["MALE_AVERAGE"] = 0] = "MALE_AVERAGE";
    BodyType[BodyType["MALE_HEAVY"] = 1] = "MALE_HEAVY";
    BodyType[BodyType["MALE_HEAVIEST"] = 2] = "MALE_HEAVIEST";
    BodyType[BodyType["MALE_SLIM"] = 3] = "MALE_SLIM";
    BodyType[BodyType["MALE_FIT"] = 5] = "MALE_FIT";
    BodyType[BodyType["MALE_HEAVIER"] = 11] = "MALE_HEAVIER";
    BodyType[BodyType["MALE_PEARSOFT"] = 13] = "MALE_PEARSOFT";
    BodyType[BodyType["MALE_HOURGLASSBODYBUILDER"] = 15] = "MALE_HOURGLASSBODYBUILDER";
    BodyType[BodyType["MALE_RECTANGLEPOWERLIFTER"] = 17] = "MALE_RECTANGLEPOWERLIFTER";
    BodyType[BodyType["FEMALE_HEAVIEST"] = 2] = "FEMALE_HEAVIEST";
    BodyType[BodyType["FEMALE_AVERAGE"] = 7] = "FEMALE_AVERAGE";
    BodyType[BodyType["FEMALE_HEAVY"] = 8] = "FEMALE_HEAVY";
    BodyType[BodyType["FEMALE_SLIM"] = 9] = "FEMALE_SLIM";
    BodyType[BodyType["FEMALE_FIT"] = 10] = "FEMALE_FIT";
    BodyType[BodyType["FEMALE_HEAVIER"] = 12] = "FEMALE_HEAVIER";
    BodyType[BodyType["FEMALE_PEARAVERAGE"] = 14] = "FEMALE_PEARAVERAGE";
    BodyType[BodyType["FEMALE_PEARXXL"] = 16] = "FEMALE_PEARXXL";
    BodyType[BodyType["FEMALE_HOURGLASSBODYBUILDER"] = 18] = "FEMALE_HOURGLASSBODYBUILDER";
})(BodyType || (BodyType = {}));
var BreastType;
(function (BreastType) {
    BreastType[BreastType["AVERAGE"] = 0] = "AVERAGE";
    BreastType[BreastType["LARGER"] = 1] = "LARGER";
    BreastType[BreastType["SMALLER"] = 3] = "SMALLER";
})(BreastType || (BreastType = {}));
class OutfitType {
    constructor() {
        this.type = "mannequin-with-head-center";
    }
}
exports.OutfitType = OutfitType;
let OutfitOverride = (() => {
    let _classDecorators = [component];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = BaseScriptComponent;
    var OutfitOverride = _classThis = class extends _classSuper {
        constructor() {
            super();
            this.remoteMediaModule = require('LensStudio:RemoteMediaModule');
            this.bitmojiModule = require('LensStudio:BitmojiModule');
            // Get these from Bitmoji 3D Component once it calls modifyBitmoji3DAvatar
            this.materialHolder = null;
            this.outfitOverrideParameters = this.outfitOverrideParameters;
            /*
                Example:
                {
                    "items":[
                        {
                            "optionId":"",
                            "type":"outerwear",
                            "globalType":"outerwear"
                        },
                        {
                            "optionId": "10093681",
                            "params": "{"primary\":16509657,\"secondary\":16509657,\"tertiary\":6899768,\"quaternary\":16509657,\"sole\":8674118,\"metal\":16509657,\"laces\":16509657,\"detail\":16509657,\"elastic\":16509657,\"furtrim\":16509657}",
                            "type":"footwear",
                            "globalType":"footwear"
                        },
                        {
                            "optionId":"10094908",
                            "params":"{\"primary\":7162163,\"secondary\":3876636,\"tertiary\":65793,\"quaternary\":65793,\"buttons\":65793,\"metal\":7162163,\"laces\":65793,\"detail\":65793,\"belt\":65793,\"furtrim\":65793}",
                            "type":"bottom",
                            "globalType":"bottom"
                        },
                        {
                            "optionId":"10095287",
                            "params":"{}",
                            "type":"top",
                            "globalType":"top"
                        }
                    ]
                }
        
                Note: globalType is used for cases when it's part of the outfit, or part of the dress
            */
            this.outfitOverrideList = this.outfitOverrideList;
            this.parametersList = [];
        }
        __initialize() {
            super.__initialize();
            this.remoteMediaModule = require('LensStudio:RemoteMediaModule');
            this.bitmojiModule = require('LensStudio:BitmojiModule');
            // Get these from Bitmoji 3D Component once it calls modifyBitmoji3DAvatar
            this.materialHolder = null;
            this.outfitOverrideParameters = this.outfitOverrideParameters;
            /*
                Example:
                {
                    "items":[
                        {
                            "optionId":"",
                            "type":"outerwear",
                            "globalType":"outerwear"
                        },
                        {
                            "optionId": "10093681",
                            "params": "{"primary\":16509657,\"secondary\":16509657,\"tertiary\":6899768,\"quaternary\":16509657,\"sole\":8674118,\"metal\":16509657,\"laces\":16509657,\"detail\":16509657,\"elastic\":16509657,\"furtrim\":16509657}",
                            "type":"footwear",
                            "globalType":"footwear"
                        },
                        {
                            "optionId":"10094908",
                            "params":"{\"primary\":7162163,\"secondary\":3876636,\"tertiary\":65793,\"quaternary\":65793,\"buttons\":65793,\"metal\":7162163,\"laces\":65793,\"detail\":65793,\"belt\":65793,\"furtrim\":65793}",
                            "type":"bottom",
                            "globalType":"bottom"
                        },
                        {
                            "optionId":"10095287",
                            "params":"{}",
                            "type":"top",
                            "globalType":"top"
                        }
                    ]
                }
        
                Note: globalType is used for cases when it's part of the outfit, or part of the dress
            */
            this.outfitOverrideList = this.outfitOverrideList;
            this.parametersList = [];
        }
        /**
         * outfitOverrideParameters is a stringified JSON object with outfit
         * override parameters which isn't presented to user in the UI..
         * It needs to be parsed and filtered to only include parameters
         * that are presented in the outfitOverrideList which is controlled by user in UI.
         *
         * e.g. if outfitOverrideParameters has Top, but user decided to exclude it from list in UI.
         */
        initializeParametersList() {
            if (this.outfitOverrideParameters) {
                const parameters = JSON.parse(this.outfitOverrideParameters);
                this.parametersList = parameters.items.filter((item) => {
                    return this.outfitOverrideList.some((other) => other.type == item.globalType);
                });
                if (this.parametersList.length == 0) {
                    return;
                }
                if (!this.parametersList.find((item) => item.type == TOP_CATEGORY)) {
                    this.parametersList.push({
                        optionId: DEFAULT_TOP_OPTION_ID,
                        params: DEFAULT_PARAMS,
                        type: TOP_CATEGORY,
                        globalType: TOP_CATEGORY
                    });
                }
                if (!this.parametersList.find((item) => item.type == BOTTOM_CATEGORY)) {
                    this.parametersList.push({
                        optionId: DEFAULT_BOTTOM_OPTION_ID,
                        params: DEFAULT_PARAMS,
                        type: BOTTOM_CATEGORY,
                        globalType: BOTTOM_CATEGORY
                    });
                }
                if (!this.parametersList.find((item) => item.type == FOOTWEAR_CATEGORY)) {
                    this.parametersList.push({
                        optionId: DEFAULT_FOOTWEAR_OPTION_ID,
                        params: DEFAULT_FOOTWEAR_PARAMS,
                        type: FOOTWEAR_CATEGORY,
                        globalType: FOOTWEAR_CATEGORY
                    });
                }
                this.parametersList = this.parametersList.map((item) => {
                    if (item.type == "footwear") {
                        item.type = "footWear";
                    }
                    if (item.type == "bottom") {
                        item.type = "bottomWear";
                    }
                    if (item.type == "outerwear") {
                        item.type = "outerWear";
                    }
                    return item;
                });
            }
            else {
                this.parametersList = [];
            }
        }
        onAwake() {
            this.initializeParametersList();
        }
        setOutfitOverrideList(list) {
            this.outfitOverrideList = list;
            this.initializeParametersList();
        }
        setOutfitOverrideParameters(parameters) {
            this.outfitOverrideParameters = parameters;
            this.initializeParametersList();
        }
        enable(bitmoji) {
            if (bitmoji.enable) {
                bitmoji.enable();
            }
            else {
                bitmoji.getAvatar().enabled = true;
            }
        }
        async modifyBitmoji3DAvatar(bitmoji) {
            if (this.parametersList.length == 0) {
                this.enable(bitmoji);
                return;
            }
            bitmoji.getAvatar().enabled = false;
            // glasses and outfit are modified in parallel
            await Promise.all([
                this.modifyBitmoji3DAvatarOutfit(bitmoji),
                this.modifyBitmoji3DAvatarGlasses(bitmoji),
            ]);
            this.enable(bitmoji);
        }
        async modifyBitmoji3DAvatarOutfit(bitmoji) {
            try {
                // bitmoji is original bitmoji avatar before outfit override
                const originalAvatarAssetExtras = JSON.parse(bitmoji.getExtras());
                this.materialHolder = bitmoji.materialHolder;
                const originalBodyNode = this.findByName(bitmoji.getAvatar(), BODY_GEO_NAME);
                // Clone the original body material to use it for the new body mesh
                const originalBodyMaterial = originalBodyNode.getComponent("RenderMeshVisual").mainMaterial.clone();
                const avatarAlternativeBody = originalAvatarAssetExtras.generator?.selectUniversalBody ||
                    AlternativeBody.DEFAULT;
                // Download default Bitmoji body mesh with the original body type and breast type
                const { sceneObject: bodySceneObject, extras: bodyExtras } = await this.downloadDefautBitmojiBody(this.parametersList, originalAvatarAssetExtras.gender, originalAvatarAssetExtras.bodyType, originalAvatarAssetExtras.breastType, avatarAlternativeBody);
                this.patchNodes(bodySceneObject, bitmoji.getAvatar(), [BODY_GROUP_NAME], bitmoji.getAvatar().getParent().layer, bitmoji.getRenderOrder(), bitmoji.getShadowsEnabled());
                this.remapSkinBones(bodySceneObject, bitmoji.getAvatar());
                // we can't destroy bodySceneObject because of skinning 
                this.findByName(bodySceneObject, AVATAR_NAME).destroy();
                const avatarBodyRenderMeshVisual = this.findByName(bitmoji.getAvatar(), BODY_GEO_NAME);
                const bodyNode = avatarBodyRenderMeshVisual.getComponent("RenderMeshVisual");
                const bodyMesh = bodyNode.mesh;
                const bodyTriangleOrder = bodyExtras.triangleOrder?.[bodyMesh.name];
                const bodyIndices = bodyMesh.getIndexBuffer();
                bodyNode.mainMaterial = originalBodyMaterial;
                const { sceneObject: clothesSceneObject, extras: clothesAssetExtras } = await this.downloadBitmojiClothes(this.parametersList, originalAvatarAssetExtras.gender, originalAvatarAssetExtras.bodyType, originalAvatarAssetExtras.breastType, avatarAlternativeBody);
                this.patchNodes(clothesSceneObject, bitmoji.getAvatar(), [CLOTHES_GROUP_NAME], bitmoji.getAvatar().getParent().layer, bitmoji.getRenderOrder(), bitmoji.getShadowsEnabled());
                this.remapSkinBones(clothesSceneObject, bitmoji.getAvatar());
                // we can't destroy clothesSceneObject because of skinning 
                this.findByName(clothesSceneObject, AVATAR_NAME).destroy();
                const facesToDelete = new Set();
                (clothesAssetExtras?.bodyFacesToDelete || []).forEach((faceId) => {
                    facesToDelete.add(faceId);
                });
                const newBodyIndices = [];
                const numFaces = bodyIndices.length / 3;
                for (let faceId = 0; faceId < numFaces; faceId++) {
                    const originalFaceId = bodyTriangleOrder
                        ? bodyTriangleOrder[faceId]
                        : faceId;
                    if (facesToDelete.has(originalFaceId)) {
                        newBodyIndices.push(0);
                        newBodyIndices.push(0);
                        newBodyIndices.push(0);
                    }
                    else {
                        newBodyIndices.push(bodyIndices[faceId * 3]);
                        newBodyIndices.push(bodyIndices[faceId * 3 + 1]);
                        newBodyIndices.push(bodyIndices[faceId * 3 + 2]);
                    }
                }
                const meshBuilder = MeshBuilder.createFromMesh(bodyMesh);
                meshBuilder.eraseIndices(0, meshBuilder.getIndicesCount());
                meshBuilder.appendIndices(newBodyIndices);
                bodyNode.mesh = meshBuilder.getMesh();
                meshBuilder.updateMesh();
            }
            catch (error) {
                print(error);
                print(error.message);
                print(error.stack);
                return null;
            }
        }
        async modifyBitmoji3DAvatarGlasses(bitmoji) {
            try {
                const glassesParameter = this.parametersList.find((item) => item.type == GLASSES_CATEGORY);
                if (!glassesParameter) {
                    return;
                }
                const { sceneObject: glassesSceneObject } = await this.downloadBitmojiGlasses(glassesParameter);
                glassesSceneObject.enabled = true;
                this.patchNodes(glassesSceneObject, bitmoji.getAvatar(), [GLASSES_GROUP_NAME], bitmoji.getAvatar().getParent().layer, bitmoji.getRenderOrder(), bitmoji.getShadowsEnabled());
                this.remapSkinBones(glassesSceneObject, bitmoji.getAvatar());
                // we can't destroy glassesSceneObject because of skinning 
                this.findByName(glassesSceneObject, AVATAR_NAME).destroy();
            }
            catch (error) {
                print(error.message);
                print(error.stack);
                return null;
            }
        }
        // @ts-ignore
        getGender(gender) {
            switch (gender) {
                case Gender.MALE:
                    // @ts-ignore
                    return Bitmoji3DOptions.Gender.Male;
                case Gender.FEMALE:
                    // @ts-ignore
                    return Bitmoji3DOptions.Gender.Female;
                default:
                    throw new Error(`Unsupported gender: ${gender}`);
            }
        }
        // @ts-ignore
        getBodyType(bodyType) {
            switch (bodyType) {
                case BodyType.MALE_AVERAGE:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MaleAverage;
                case BodyType.MALE_HEAVY:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MaleHeavy;
                case BodyType.MALE_HEAVIEST:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MaleHeaviest;
                case BodyType.MALE_SLIM:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MaleSlim;
                case BodyType.MALE_FIT:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MaleFit;
                case BodyType.MALE_HEAVIER:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MaleHeavier;
                case BodyType.FEMALE_HEAVIEST:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemaleHeaviest;
                case BodyType.FEMALE_AVERAGE:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemaleAverage;
                case BodyType.FEMALE_HEAVY:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemaleHeavy;
                case BodyType.FEMALE_SLIM:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemaleSlim;
                case BodyType.FEMALE_FIT:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemaleFit;
                case BodyType.FEMALE_HEAVIER:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemaleHeavier;
                case BodyType.FEMALE_PEARAVERAGE:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemalePearAverage;
                case BodyType.FEMALE_PEARXXL:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemalePearXXL;
                case BodyType.FEMALE_HOURGLASSBODYBUILDER:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.FemaleHourGlassBodyBuilder;
                case BodyType.MALE_PEARSOFT:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MalePearsoft;
                case BodyType.MALE_HOURGLASSBODYBUILDER:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MaleHourGlassBodyBuilder;
                case BodyType.MALE_RECTANGLEPOWERLIFTER:
                    // @ts-ignore
                    return Bitmoji3DOptions.BodyType.MaleRectanglePowerLifter;
                default:
                    throw new Error(`Unsupported body type: ${bodyType}`);
            }
        }
        // @ts-ignore
        getBreastType(breastType) {
            switch (breastType) {
                case BreastType.AVERAGE:
                    // @ts-ignore
                    return Bitmoji3DOptions.BreastType.Average;
                case BreastType.LARGER:
                    // @ts-ignore
                    return Bitmoji3DOptions.BreastType.Larger;
                case BreastType.SMALLER:
                    // @ts-ignore
                    return Bitmoji3DOptions.BreastType.Smaller;
                default:
                    throw new Error(`Unsupported breast type: ${breastType}`);
            }
        }
        createBodyParams(gender, bodyType, breastType) {
            // @ts-ignore
            const bodyParams = Bitmoji3DOptions.BaseBodyParams.create();
            // @ts-ignore 
            bodyParams.gender = this.getGender(gender);
            // @ts-ignore
            bodyParams.bodyType = this.getBodyType(bodyType);
            // @ts-ignore
            bodyParams.breastType = this.getBreastType(breastType);
            return bodyParams;
        }
        async downloadDefautBitmojiBody(parameters, gender, bodyType, breastType, alternativeBody) {
            const options = Bitmoji3DOptions.create();
            const customParams = Bitmoji3DOptions.CustomParams.create();
            customParams.clothingType = Bitmoji3DOptions.ClothingType.SplitClothes;
            customParams.avatarScope = Bitmoji3DOptions.AvatarScope.Body;
            // If original Bitmoji has socks, download mesh with socks, otherwise download mesh with toes
            const sockParam = Bitmoji3DOptions.ParamSet.create();
            sockParam.optionId = alternativeBody === AlternativeBody.SOCK ? "295" : "0";
            customParams.sock = sockParam;
            parameters.forEach((parameter) => {
                if (parameter.type == "footWear") {
                    const param = Bitmoji3DOptions.ParamSet.create();
                    param.optionId = parameter.optionId;
                    if (parameter.params) {
                        param.params = JSON.parse(parameter.params);
                    }
                    customParams[parameter.type] = param;
                }
            });
            options.customParams = customParams;
            options.requestType = Bitmoji3DOptions.RequestType.Custom;
            const bodyParams = this.createBodyParams(gender, bodyType, breastType);
            const bitmoji3DResource = await this.getDefaultBitmojiResource(options, bodyParams);
            const gltfAsset = await this.download3DAsset(bitmoji3DResource);
            return await this.instantiateGLTFAsset(gltfAsset, this.materialHolder, this.gltfSettings(true));
        }
        async downloadBitmojiClothes(parameters, gender, bodyType, breastType, alternativeBody) {
            const options = Bitmoji3DOptions.create();
            const customParams = Bitmoji3DOptions.CustomParams.create();
            customParams.clothingType = Bitmoji3DOptions.ClothingType.SplitClothes;
            customParams.avatarScope = Bitmoji3DOptions.AvatarScope.Clothes;
            parameters.forEach((parameter) => {
                if (parameter.type == "" || parameter.type == GLASSES_CATEGORY) {
                    return;
                }
                const param = Bitmoji3DOptions.ParamSet.create();
                param.optionId = parameter.optionId;
                if (parameter.params) {
                    param.params = JSON.parse(parameter.params);
                }
                customParams[parameter.type] = param;
            });
            // If original Bitmoji has socks, download mesh with socks, otherwise download mesh with toes
            const sockParam = Bitmoji3DOptions.ParamSet.create();
            sockParam.optionId = alternativeBody === AlternativeBody.SOCK ? "295" : "0";
            customParams.sock = sockParam;
            options.customParams = customParams;
            options.requestType = Bitmoji3DOptions.RequestType.Custom;
            const bodyParams = this.createBodyParams(gender, bodyType, breastType);
            const bitmoji3DResource = await this.getDefaultBitmojiResource(options, bodyParams);
            const gltfAsset = await this.download3DAsset(bitmoji3DResource);
            return await this.instantiateGLTFAsset(gltfAsset, this.materialHolder, this.gltfSettings());
        }
        async downloadBitmojiGlasses(parameter) {
            try {
                const options = Bitmoji3DOptions.create();
                const customParams = Bitmoji3DOptions.CustomParams.create();
                customParams.clothingType = Bitmoji3DOptions.ClothingType.SplitClothes;
                customParams.avatarScope = Bitmoji3DOptions.AvatarScope.Glasses;
                customParams.glasses = parameter.optionId;
                options.customParams = customParams;
                options.requestType = Bitmoji3DOptions.RequestType.Custom;
                const bodyParams = this.createBodyParams(Gender.MALE, BodyType.MALE_AVERAGE, BreastType.AVERAGE);
                const bitmoji3DResource = await this.getDefaultBitmojiResource(options, bodyParams);
                const gltfAsset = await this.download3DAsset(bitmoji3DResource);
                return await this.instantiateGLTFAsset(gltfAsset, this.materialHolder, this.gltfSettings());
            }
            catch (error) {
                print(error.message);
                print(error.stack);
                return null;
            }
        }
        // Bitmoji Download {
        // to-do: enable types
        async getDefaultBitmojiResource(options, bodyParameters) {
            return new Promise((resolve, reject) => {
                // @ts-ignore
                this.bitmojiModule.requestBaseBitmoji3DResourceWithOptions(options, bodyParameters, resolve);
            });
        }
        async download3DAsset(bitmoji3DResource) {
            return new Promise((resolve, reject) => {
                this.remoteMediaModule.loadResourceAsGltfAsset(bitmoji3DResource, resolve, reject);
            });
        }
        gltfSettings(storeTriangleOrder = false) {
            let settings = GltfSettings.create();
            settings.convertMetersToCentimeters = true;
            settings.optimizeGeometry = true;
            settings.storeTriangleOrder = storeTriangleOrder;
            return settings;
        }
        async instantiateGLTFAsset(gltfAsset, materialHolder, settings) {
            return new Promise((resolve, reject) => {
                gltfAsset.tryInstantiateAsync(this.getSceneObject(), materialHolder, (avatar) => {
                    avatar.enabled = false;
                    resolve({ sceneObject: avatar, extras: JSON.parse(gltfAsset.extras) });
                }, (error) => {
                    print(error);
                    reject(error);
                }, () => {
                }, settings);
            });
        }
        // } Bitmoji Download
        // Bitmoji Post-Processing {
        remapSkinBones(patchSceneObject, avatarSceneObject) {
            const patchSkinNode = this.findSceneObjectInHierarchy(patchSceneObject, (sceneObject) => {
                return !!sceneObject.getComponent("Skin");
            });
            const avatarSkinNode = this.findSceneObjectInHierarchy(avatarSceneObject, (sceneObject) => {
                return !!sceneObject.getComponent("Skin");
            });
            if (!patchSkinNode || !avatarSkinNode) {
                const errorMessage = "Skin node not found in patch or avatar";
                throw new Error(errorMessage);
            }
            const patchSkin = patchSkinNode.getComponent("Skin");
            const avatarSkin = avatarSkinNode.getComponent("Skin");
            for (const boneName of patchSkin.getSkinBoneNames()) {
                const avatarBoneNode = avatarSkin.getSkinBone(boneName);
                patchSkin.setSkinBone(boneName, avatarBoneNode);
            }
        }
        ;
        fixRenderLayer(root, layer) {
            this.fixGroup(root, (so) => { so.layer = layer; });
        }
        fixCastShadows(root, castShadows) {
            this.fixGroup(root, (so) => {
                const rmv = so.getComponent("RenderMeshVisual");
                if (rmv) {
                    rmv.meshShadowMode = castShadows ? MeshShadowMode.Caster : MeshShadowMode.None;
                }
            });
        }
        fixRenderOrder(root, renderOrder) {
            this.fixGroup(root, (so) => {
                const rmv = so.getComponent("RenderMeshVisual");
                if (rmv) {
                    rmv.renderOrder = renderOrder;
                }
            });
        }
        fixGroup(sceneObject, func) {
            func(sceneObject);
            sceneObject.children.forEach((child) => {
                this.fixGroup(child, func);
            });
        }
        patchNodes(patchSceneObject, avatarSceneObject, nodeGroupNames, renderLayer, renderOrder, castShadows) {
            for (const nodeGroupName of nodeGroupNames) {
                //print(`Patch node group ${nodeGroupName}`);
                const patchGroupNode = this.findByName(patchSceneObject, nodeGroupName);
                const avatarGroupNode = this.findByName(avatarSceneObject, nodeGroupName);
                if (avatarGroupNode) {
                    const parent = avatarGroupNode.getParent();
                    if (!parent) {
                        //print(`Avatar group node ${nodeGroupName} has no parent`);
                        continue;
                    }
                    // Remove current group node
                    //print(`Destroying old avatar group node ${nodeGroupName}`);
                    avatarGroupNode.destroy();
                    // Add new group node
                    if (patchGroupNode) {
                        // print(`Set patch group node ${nodeGroupName} parent to ${parent.name} in avatar scene object`);
                        this.fixRenderLayer(patchGroupNode, renderLayer);
                        this.fixRenderOrder(patchGroupNode, renderOrder);
                        this.fixCastShadows(patchGroupNode, castShadows);
                        patchGroupNode.setParent(parent);
                    }
                }
                else if (patchGroupNode) {
                    const patchGroupNodeParent = patchGroupNode.getParent();
                    if (!patchGroupNodeParent) {
                        // print(`Patch group node ${nodeGroupName} has no parent`);
                        continue;
                    }
                    const avatarNodeParent = this.findByName(avatarSceneObject, patchGroupNodeParent.name);
                    if (!avatarNodeParent) {
                        //print(`Avatar node parent ${patchGroupNodeParent.name} not found`);
                        continue;
                    }
                    this.fixRenderLayer(patchGroupNode, renderLayer);
                    this.fixRenderOrder(patchGroupNode, renderOrder);
                    this.fixCastShadows(patchGroupNode, castShadows);
                    //print(`Adding new patch group to avatar ${nodeGroupName}`);
                    patchGroupNode.setParent(avatarNodeParent);
                }
                else {
                    //print(`No ${nodeGroupName} node group found in patch scene object or avatar scene object`);
                }
            }
        }
        ;
        // } Bitmoji Post-Processing
        // Utils {
        findByName(node, name) {
            if (node.name === name) {
                return node;
            }
            for (const child of node.children) {
                const found = this.findByName(child, name);
                if (found) {
                    return found;
                }
            }
            return undefined;
        }
        findSceneObjectInHierarchy(node, predicate) {
            if (predicate(node)) {
                return node;
            }
            for (const child of node.children) {
                const found = this.findSceneObjectInHierarchy(child, predicate);
                if (found) {
                    return found;
                }
            }
            return undefined;
        }
    };
    __setFunctionName(_classThis, "OutfitOverride");
    (() => {
        const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        OutfitOverride = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return OutfitOverride = _classThis;
})();
exports.OutfitOverride = OutfitOverride;
//# sourceMappingURL=Outfit%20Override.js.map