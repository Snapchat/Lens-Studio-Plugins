// @input SceneObject scene

let cameraTransform = script.scene.getTransform();

let isScale = false;

let prevTouchPos = new vec2(0, 0);
let diffTouchPos = new vec2(0, 0);
let touchPos = new vec2(0, 0);

let touchIds = [];
const initialRotation = cameraTransform.getLocalRotation();

script.reset = () => {
    cameraTransform.setLocalRotation(initialRotation);
}

script.createEvent("UpdateEvent").bind(function() {
    var rotation = cameraTransform.getLocalRotation();
    var rotateBy = quat.angleAxis(2 * Math.PI * -diffTouchPos.x, vec3.up());
    rotation = rotation.multiply(rotateBy);
    cameraTransform.setLocalRotation(rotation);
});


script.createEvent("TouchStartEvent").bind(function(eventData) {
    prevTouchPos = eventData.getTouchPosition();
    touchIds.push(eventData.getTouchId());
    if (touchIds.length > 1) {
        isScale = true;
    }
});

script.createEvent("TouchMoveEvent").bind(function(eventData) {
    if (touchIds.length > 1 || isScale) {
        return;
    }
    touchPos = eventData.getTouchPosition();
    diffTouchPos = prevTouchPos.sub(touchPos);
    prevTouchPos = touchPos;
});

script.createEvent("TouchEndEvent").bind(function() {
    if(touchIds.length > 0) {
        touchIds.pop();
    }
    if (touchIds.length == 0) {
        isScale = false;
    }
    diffTouchPos = vec2.zero();
});
