/*
@typedef cameraPosition
@property {vec3} position
@property {vec3} rotation
@property {string} id
*/

const TWEEN = require("TweenManager/Tween/Tween");

// @input cameraPosition[] cameraSpots
// @input Component.Camera camera
// @input SceneObject so
// @input SceneObject scene

const DEFAULT_TARGET_NAME = "full_body";
const DEG_TO_RAD = 0.0174533;

const spots = script.cameraSpots.reduce((acc, spot) => {
    acc[spot.id] = { position: spot.position, rotation: spot.rotation };
    return acc;
}, {});

let Tween = global.tweenManager;

script.moveTo = (targetName, immediate) => {
    if (!targetName || !spots[targetName]) {
        targetName = DEFAULT_TARGET_NAME;
    }

    const endPos = spots[targetName].position;
    const endRot = quat.fromEulerVec(spots[targetName].rotation.uniformScale(DEG_TO_RAD))

    Tween.stopTween(script.so, 'position');
    Tween.stopTween(script.so, 'rotation');

    if (immediate) {
        script.so.getTransform().setLocalPosition(endPos);
        script.so.getTransform().setLocalRotation(endRot);
    } else {
        Tween.setEndValue(script.so, "position", endPos);
        Tween.setEndValue(script.so, "rotation", endRot);

        Tween.startTween(script.so, "position");
        Tween.startTween(script.so, "rotation");
    }
};
