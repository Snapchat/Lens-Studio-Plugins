const remoteMediaModule = require('LensStudio:RemoteMediaModule');
const bitmojiModule = require('LensStudio:BitmojiModule');

// @input Asset.Material materialHolder
// @input Component.AnimationPlayer defaultPlayer
// @input Component.AnimationPlayer heavyPlayer
// Bitmoji Download {

async function getBitmojiResource(options) {
    return new Promise(function (resolve, reject) {
        bitmojiModule.requestBitmoji3DResourceWithOptions(options, resolve);
    });
}

async function download3DAsset(bitmoji3DResource) {
    return new Promise(function (resolve, reject) {
        remoteMediaModule.loadResourceAsGltfAsset(
            bitmoji3DResource,
            resolve,
            reject
        );
    });
}

async function instantiateGLTFAsset(gltfAsset) {
    return new Promise((resolve, reject) => {
        let settings = GltfSettings.create();
        settings.convertMetersToCentimeters = true;
        settings.optimizeGeometry = true;
        settings.storeTriangleOrder = true;

        gltfAsset.tryInstantiateAsync(
            script.getSceneObject(),
            script.materialHolder,
            (avatar) => {
                resolve({ avatar, extras: gltfAsset.extras });
            },
            (error) => {
                reject(error);
            },
            () => {

            },
            settings
        );
    });
}

// } Bitmoji Download


script.fixLayers = () => {
    const traverse = (so, renderLayer) => {
        so.layer = renderLayer;

        const rmv = so.getComponent("RenderMeshVisual");
        if (rmv) {
            rmv.meshShadowMode = MeshShadowMode.Caster;
        };

        so.children.forEach((child) => {
           traverse(child, renderLayer);
        });
    }

    traverse(script.avatar, script.getSceneObject().layer);
}

const setAvatar = (avatar) => {
    avatar.setParent(script.getSceneObject());

    onAvatarUpdated(script.avatar);

    script.oldAvatar = script.avatar;

    script.avatar = avatar;
    script.fixLayers();
}

script.bitmojiType = null;
script.friendIndex = -1;

// parameter list is for case when we need to include footwear in Bitmoji request
script.setUser = async (type, friendIndex = -1) => {
    script.currentUser = await getUser(type, friendIndex);
    await script.refreshBitmoji(script.currentUser);

    script.bitmojiType = type;
    script.friendIndex = friendIndex;

    return script.getAvatar();
}

script.getUser = () => {
    return script.currentUser;
}

script.getAvatar = () => {
    return script.avatar;
}

script.getRenderOrder = () => {
    return 0;
}

script.getShadowsEnabled = () => {
    return true;
}

const setExtras = (extras) => {
    script.extras = extras;
}

script.getExtras = () => {
    return script.extras;
}

script.enable = () => {
    if (script.avatar) {
        if (script.oldAvatar) {
            script.oldAvatar.destroy();
            script.oldAvatar = null;
        }

        const animationBodyType = JSON.parse(script.getExtras()).animationBodyType;

        if (animationBodyType == "default") {
            script.heavyPlayer.enabled = false;
            script.defaultPlayer.enabled = true;
        } else {
            script.heavyPlayer.enabled = true;
            script.defaultPlayer.enabled = false;
        }

        script.avatar.enabled = true;
    }
}

script.refreshBitmoji = async (user) => {
    if (!user) {
        return;
    }

    let options = Bitmoji3DOptions.create();
    options.user = user;

    const bitmoji3DResource = await getBitmojiResource(options);
    const gltfAsset = await download3DAsset(bitmoji3DResource);
    const { avatar, extras } = await instantiateGLTFAsset(gltfAsset);

    avatar.enabled = false;

    setExtras(extras);
    setAvatar(avatar);
}

const pendingRequestsForBitmoji = [];

const onAvatarUpdated = async (avatar) => {
    pendingRequestsForBitmoji.forEach(async (cb) => {
        await cb(avatar);
    });

    pendingRequestsForBitmoji.length = 0;
}

script.waitForBitmoji = (cb) => {
    if (script.avatar) {
        cb(script.avatar);
    } else {
        pendingRequestsForBitmoji.push(cb);
    }
}

async function getUser(bitmojiType, friendIndex) {
    switch(bitmojiType) {
        case 1:
            // friend
            return new Promise((resolve) => {
                global.userContextSystem.getAllFriends((users) => {
                    if (!friendIndex) {
                        friendIndex = 0;
                    }
                    const friend = users[friendIndex % users.length];
                    resolve(friend);
                });
            });
        case 2:
            // my ai
            return new Promise((resolve) => {
                global.userContextSystem.getMyAIUser((user) => {
                    resolve(user);
                });
            });
        default:
            // current user
            return new Promise((resolve) => {
                global.userContextSystem.getCurrentUser((user) => {
                    resolve(user);
                });
            });
    }
}
