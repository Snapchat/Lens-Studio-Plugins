// @input Component.Camera camera

const minHeight = 20;
const maxHeight = 100;

let cameraTransform = script.camera.getTransform();

let isScale = false;

let prevTouchPos = new vec2(0, 0);
let diffTouchPos = new vec2(0, 0);
let touchPos = new vec2(0, 0);

let touchIds = [];
const initialRotation = cameraTransform.getLocalRotation();

script.reset = () => {
    cameraTransform.setLocalRotation(initialRotation);
}

script.createEvent("UpdateEvent").bind(function() {
    var position = cameraTransform.getLocalPosition();

    if (position.x*position.x + position.z*position.z < 160*160) {
        position.y = MathUtils.clamp(position.y + (-diffTouchPos.y * (maxHeight - minHeight)), minHeight, maxHeight)

        cameraTransform.setLocalPosition(position);
    }
});


script.createEvent("TouchStartEvent").bind(function(eventData) {
    prevTouchPos = eventData.getTouchPosition();
    touchIds.push(eventData.getTouchId());
    if (touchIds.length > 1) {
        isScale = true;
    }
});

script.createEvent("TouchMoveEvent").bind(function(eventData) {
    if (touchIds.length > 1 || isScale) {
        return;
    }
    touchPos = eventData.getTouchPosition();
    diffTouchPos = prevTouchPos.sub(touchPos);
    prevTouchPos = touchPos;
});

script.createEvent("TouchEndEvent").bind(function() {
    if(touchIds.length > 0) {
        touchIds.pop();
    }
    if (touchIds.length == 0) {
        isScale = false;
    }
    diffTouchPos = vec2.zero();
});
