// @input Component.ScriptComponent clothComponent
// @input Component.ScriptComponent cameraController

try {
    script.createEvent("MessageEvent").bind((event) => {
        if (event && event.data) {
            const type = event.data.event_type;

            if (type == "update") {
                const params = event.data.params;
                if (params) {
                    script.clothComponent.updateClothes(params, event.data.bitmojiType, event.data.friendIndex);
                }

            } else if (type == "change_camera") {
                const spotName = event.data.spotName;

                script.cameraController.moveTo(spotName, event.data.immediate);
            } else if (type == "request_bitmoji_data") {
                script.clothComponent.requestBitmojiData((data) => {
                    Editor.context.postMessage({
                        "event_type": "bitmoji_data",
                        "event_value": JSON.stringify(data)
                    });
                });
            }

        }
    });
} catch(error) {

}

script.init = function() {

}

script.reset = function() {

}

let startDelayedEvent = script.createEvent("DelayedCallbackEvent");
startDelayedEvent.bind(() => {
   try {
    Editor.context.postMessage({
        "event_type": "start"
    });
   } catch (error) {
        startDelayedEvent.reset(0);
   }
});

script.createEvent("OnStartEvent").bind(() => {
    startDelayedEvent.reset(0);
});
