//@input SceneObject animParent
//@input Component.ScriptComponent bitmoji3DComponent
//@input SceneObject bodyMorphObj
//@input Asset.Material bodyMorphMaterial
//@input Asset.Material emptyMaterial
//@input SceneObject skeleton
//@input Asset.AnimationAsset defaultAnimAsset

var transformData = [];
var bmTransformData = {};
var bitmojiObj = script.bitmoji3DComponent.getSceneObject();
var bodyMorphObjT = script.bodyMorphObj.getTransform();
var animParentT = script.animParent.getTransform();
var videoAnimPos = new vec3(0, 60, 200);
var bodyMorphAnimPos = new vec3(0, 110, 400);
var localAnimPlayer = script.animParent.getComponent("Component.AnimationPlayer");
var curState = 0;
var hipsObj = null;
var isCurAnimVideo = false;

init();

function init() {
    script.bitmoji3DComponent.onDownloaded.add(() => {
        getTransformData(bitmojiObj);
    })
    
    script.bitmoji3DComponent.download();
    
    getBMTransformData(script.skeleton);   
}

script.createEvent("MessageEvent").bind((event) => {
    
    if (event.data.event_type == "select_bitmoji") {
        script.bodyMorphObj.enabled = false;
        bitmojiObj.enabled = true;
        curState = 0;
        return;
    }    
    
    if (event.data.event_type == "select_body_morph") {
        bitmojiObj.enabled = false;
        script.bodyMorphObj.enabled = true;
        curState = 1;
        return;
    }   
    
    if (event.data.event_type == "reset_animation") {
        script.bodyMorphObj.enabled = false;
        bitmojiObj.enabled = false;      
        resetAnimations();
        return;
    }
    
    if (event.data.event_type == "update_animation") {
        script.bodyMorphObj.enabled = false;
        bitmojiObj.enabled = false;        
            
        isCurAnimVideo = (event.data.type == "video")
        
        const path = event.data.path;
    
        if (event.data.type == "video" && event.data.character == 1) {
            global.assetSystem.downloadAssetFromUrl(
            (id, path, asset) => {
                var obj = asset.tryInstantiate(script.getSceneObject(), script.emptyMaterial);
                setNewAnimation(event, obj);
            },
            () => {},
            "file://" + path,
            ""
            )
        }
        else {
            var obj = Editor.importFbx(path);
            setNewAnimation(event, obj);
        }
        
        return;
    }
    
    if (event.data.event_type == "update_body_morph") {
        if (event.data.path.length > 0 && event.data.path[0] != '/') {
            event.data.path = "/" + event.data.path;
        }
        script.bodyMorphObj.enabled = false;
        if (script.bodyMorphObj.getChildrenCount() > 0) {
            script.bodyMorphObj.getChild(0).destroy();
        }
        
        localAnimPlayer.stopAll();        
        
        global.assetSystem.downloadAssetFromUrl(
            (id, path, asset) => {
                var obj = asset.tryInstantiate(script.bodyMorphObj, script.bodyMorphMaterial);
                localAnimPlayer.stopAll(); 
                localAnimPlayer.playAll();
                localAnimPlayer.forceUpdate(0);
            
                setBMTransformData(script.bodyMorphObj);

                setLayers(obj);
                script.bodyMorphObj.enabled = true;
            },
            () => {},
            "file://" + event.data.path,
            ""
        )      
        
        return;
    }
})

function setNewAnimation(event, obj) {
    var animPlayer = obj.getComponent("Component.AnimationPlayer");
    if (!animPlayer) {
        animPlayer = obj.getChild(0).getChild(0).getComponent("Component.AnimationPlayer");
    }
    var clip = animPlayer.clips[0];
    
    if (localAnimPlayer.clips.length > 0) {
        localAnimPlayer.removeClip(localAnimPlayer.clips[0].name)
        localAnimPlayer.forceUpdate(0);
    }
    
    if (curState == 0) {
        resetBlendShapes(bitmojiObj);
        setTransformData();
    }
    else {
        setBMTransformData(script.bodyMorphObj);
    }
    
    clip.begin = 0.0333;
    localAnimPlayer.addClip(clip);
    localAnimPlayer.playAll();
    localAnimPlayer.forceUpdate(0);
    obj.destroy();
    
    if (event.data.type == "video") {
        animParentT.setLocalPosition(videoAnimPos);
    }
    else {
        animParentT.setLocalPosition(vec3.zero());
    }
    
    if (curState == 0) {
        bitmojiObj.enabled = true;
    }
    else {
        script.bodyMorphObj.enabled = true;
    }
}

function resetAnimations() {
    var clip = localAnimPlayer.clips[0];
    clip.animation = script.defaultAnimAsset;
    clip.end = script.defaultAnimAsset.duration;
    
    if (curState == 0) {
        resetBlendShapes(bitmojiObj);
        setTransformData();
    }
    else {
        setBMTransformData(script.bodyMorphObj);
    }
    
    localAnimPlayer.playAll();
    localAnimPlayer.forceUpdate(0);
    
    animParentT.setLocalPosition(vec3.zero());
    
    if (curState == 0) {
        bitmojiObj.enabled = true;
    }
    else {
        script.bodyMorphObj.enabled = true;
    }
}

function resetBlendShapes(obj) {
    if (obj.name === "C_brow_GEO" || obj.name === "C_head_GEO" || obj.name === "universal_head_eyelash_GEO") {
        var renderMeshVisual = obj.getComponent("Component.RenderMeshVisual");
        if (renderMeshVisual && renderMeshVisual.blendShapesEnabled) {
            var blendShapeNames = renderMeshVisual.getBlendShapeNames();
            blendShapeNames.forEach(function(name) {
                obj.getComponent("Component.RenderMeshVisual").setBlendShapeWeight(name, 0);
            })
        }
    }
    
    for (var i = 0; i < obj.getChildrenCount(); i++) {
        resetBlendShapes(obj.getChild(i));
    }
}

function getTransformData(obj) {
    var transform = obj.getTransform();
    transformData.push({transform : transform, localPosition : transform.getLocalPosition(), localRotation : transform.getLocalRotation(), localScale : transform.getLocalScale()})
    
    for (var i = 0; i < obj.getChildrenCount(); i++) {
        getTransformData(obj.getChild(i));
    }
}

function setTransformData() {
    transformData.forEach(function(data) {
        data.transform.setLocalPosition(data.localPosition);
        data.transform.setLocalRotation(data.localRotation);
        data.transform.setLocalScale(data.localScale);
    })
}

function getBMTransformData(obj) {
    var transform = obj.getTransform();
    bmTransformData[obj.name] = {transform : transform, localPosition : transform.getLocalPosition(), localRotation : transform.getLocalRotation(), localScale : transform.getLocalScale()};

    for (var i = 0; i < obj.getChildrenCount(); i++) {
        getBMTransformData(obj.getChild(i));
    }
}

function setBMTransformData(obj) {
    if (bmTransformData[obj.name]) {
        var data = bmTransformData[obj.name];
        obj.getTransform().setLocalPosition(data.localPosition);
        obj.getTransform().setLocalRotation(data.localRotation);
        obj.getTransform().setLocalScale(data.localScale);
    }
    
    for (var i = 0; i < obj.getChildrenCount(); i++) {
        setBMTransformData(obj.getChild(i));
    }
}

function setLayers(obj) {
    obj.layer = bitmojiObj.layer;
    
    for (var i = 0; i < obj.getChildrenCount(); i++) {
        setLayers(obj.getChild(i));
    }
}