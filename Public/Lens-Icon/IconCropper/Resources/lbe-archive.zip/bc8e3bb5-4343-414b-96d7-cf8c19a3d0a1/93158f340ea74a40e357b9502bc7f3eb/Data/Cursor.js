// @input Asset.Texture[] macTextures
// @input Asset.Texture[] winTextures

const CursorType = {
    ClosedHand: 0,
    OpenHand: 1,
    Scale_v1: 2,
    Scale_v2: 3,
    Default: 4,
    Custom: 5,
}

script.CursorType = CursorType;

const RequestType = {
    SetCursor: "setCursor",
    UnsetCursor: "unsetCursor",
}

let lastCursorID = "";
let lastRotation = 0;

let requestsQueue = [];
let cursorsStack = [];
let idToTexture = {};
let isActiveProcessing= false;
let isLocked = false;

let currentCursorType = CursorType.Default;

script.setCursor = function(type) {
    if (type === CursorType.Default) {
        resetCursorTexture(0);
    } else {
        setCursorTexture(0, type);
    }
}

function setCursorTexture(id, type) {
    requestsQueue.push([RequestType.SetCursor, type]);

    if (!isActiveProcessing && requestsQueue.length) {
        startProcessing();
    }
}

function resetCursorTexture(id) {
    requestsQueue.push([RequestType.UnsetCursor, null]);
    if (!isActiveProcessing) {
        startProcessing();
    }
}

function startProcessing() {
    isActiveProcessing = true;
    const request = requestsQueue.shift();
    performRequest(request[0], request[1]).then(() => {
        if (requestsQueue.length)  {
            startProcessing();
        } else {
            isActiveProcessing = false;
        }
    }).catch((err) => {
    })
}

function createOrUpdateCursor(id, texture) {
    let cursorIdx = cursorsStack.indexOf(id);
    if (cursorIdx < 0) {
        cursorsStack.push(id);
    }
    idToTexture[id] = texture;
}

function radToDeg(angle) {
    return angle * 180 / Math.PI;
}

function degToRad(angle) {
    return angle * Math.PI / 180;
}

async function performRequest(requestType, cursorType) {
    if (requestType == RequestType.SetCursor && cursorType == currentCursorType) {
        return;
    }

    const request = RemoteApiRequest.create();

    request.endpoint = requestType;

    if (requestType === RequestType.SetCursor) {
        if (global.deviceInfoSystem.getOS() === OS.MacOS) {
            request.uriResources = [await convertTexture(script.macTextures[Math.round(cursorType)])];
        }
        if (global.deviceInfoSystem.getOS() === OS.Windows) {
            request.uriResources = [await convertTexture(script.winTextures[Math.round(cursorType)])];
        }
    }

    CursorRemoteServiceModule.performApiRequest(request, (response) => {
        if (response.statusCode !== 200) {
        } else {
            currentCursorType = cursorType;
        }
    })
}

function last(arr) {
    return arr[arr.length - 1];
}

async function convertTexture(texture) {
    return CursorRemoteMediaModule.createImageResourceForTexture(texture, CursorTextureUploadOptions);
}

const CursorTextureUploadOptions = ImageUploadOptions.create();
CursorTextureUploadOptions.compressionQuality = CompressionQuality.MaximumQuality;
CursorTextureUploadOptions.compressionMethod = ImageUploadCompressionMethod.PNG;
CursorTextureUploadOptions.includeAlpha = true;

CursorRemoteMediaModule = global.assetSystem.createAsset("Asset.RemoteMediaModule");
CursorRemoteServiceModule = global.assetSystem.createAsset("Asset.RemoteServiceModule");
CursorRemoteServiceModule.apiSpecId = 'editor';
