const checkColorSimilarity = (c1, c2) => {
    const tolerance = 25;
    const redDistance = Math.abs(c1.r - c2.r);
    const greenDistance = Math.abs(c1.g - c2.g);
    const blueDistance = Math.abs(c1.b - c2.b);
    const alphaDistance = Math.abs(c1.a - c2.a);

    return redDistance < tolerance &&
           greenDistance < tolerance &&
           blueDistance < tolerance &&
           alphaDistance < tolerance &&
           (redDistance + greenDistance + blueDistance + alphaDistance) * 4 <= tolerance * 5;
}

script.getCroppingCircle = function (pixelsData, width, height) {
    const getPixel = (i, j) => {
        const index = Math.floor((j * width + i) * 4);
        return new vec4(pixelsData[index], pixelsData[index + 1], pixelsData[index + 2], pixelsData[index + 3]);
    }

    const bgColor = getPixel(0, 0);

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            // Get the current pixel color
            let pixelColor = getPixel(x, y);
            // Check if the pixel is not similar to the background color
            if (!checkColorSimilarity(pixelColor, bgColor)) {
                // Update the bounding box coordinates
                if (x < minX) minX = x;
                if (y < minY) minY = y;
                if (x > maxX) maxX = x;
                if (y > maxY) maxY = y;
            }
        }
    }
     // Check if no non-background pixels were found
    if (minX === Infinity || minY === Infinity || maxX === -Infinity || maxY === -Infinity) {
        // Return null or an empty box if no non-background pixels were found
        return;
    }

    croppingCircle = {
        center: new vec2((maxX + minX) / 2, (maxY + minY) / 2),
        radius: Math.min((maxX - minX + 1), (maxY - minY + 1)) / 2
    }

    return croppingCircle;
}
