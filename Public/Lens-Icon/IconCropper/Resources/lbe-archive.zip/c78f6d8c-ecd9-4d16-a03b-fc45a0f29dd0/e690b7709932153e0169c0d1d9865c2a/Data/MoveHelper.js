// @input Component.ScreenTransform bottomLeftSt
// @input Component.ScreenTransform bottomRightSt
// @input Component.ScreenTransform topLeftSt
// @input Component.ScreenTransform topRightSt

// @input Component.ScriptComponent controller
// @input Component.ScriptComponent cursor

const GIZMO_TYPE = {
    BOTTOM_LEFT: 0,
    BOTTOM_RIGHT: 1,
    TOP_LEFT: 2,
    TOP_RIGHT: 3,
    CIRCLE: 4
}

let activeGizmo = null;
let lastPosition = null;

function remap(a, b, c, d, x) {
    return c + ((x - a) / (b - a)) * (d - c);
}

function remapPoint(point) {
    return new vec2(
        remap(0, 1, -1, 1, point.x),
        remap(0, 1, -1, 1, point.y)
    );
}

function isCircle(pos) {
    if (pos.x < script.topLeftSt.localPointToScreenPoint(new vec2(0, 0)).x) {
        return false;
    }

    if (pos.x > script.bottomRightSt.localPointToScreenPoint(new vec2(0, 0)).x) {
        return false;
    }

    if (pos.y < script.bottomRightSt.localPointToScreenPoint(new vec2(0, 0)).y) {
        return false;
    }

    if (pos.y > script.topLeftSt.localPointToScreenPoint(new vec2(0, 0)).y) {
        return false;
    }

    return true;
}

let activeTouch = false;

script.createEvent("TouchStartEvent").bind((eventData) => {
    const pos = eventData.getTouchPosition();

    if (script.topLeftSt.containsScreenPoint(pos)) {
        activeGizmo = GIZMO_TYPE.TOP_LEFT;
        lastPosition = remapPoint(pos);
        script.cursor.setCursor(script.cursor.CursorType.Scale_v1);
    } else if (script.bottomLeftSt.containsScreenPoint(pos)) {
        activeGizmo = GIZMO_TYPE.BOTTOM_LEFT;
        lastPosition = remapPoint(pos);
        script.cursor.setCursor(script.cursor.CursorType.Scale_v2);
    } else if (script.bottomRightSt.containsScreenPoint(pos)) {
        activeGizmo = GIZMO_TYPE.BOTTOM_RIGHT;
        lastPosition = remapPoint(pos);
        script.cursor.setCursor(script.cursor.CursorType.Scale_v1);
    } else if (script.topRightSt.containsScreenPoint(pos)) {
        activeGizmo = GIZMO_TYPE.TOP_RIGHT;
        lastPosition = remapPoint(pos);
        script.cursor.setCursor(script.cursor.CursorType.Scale_v2);
    } else if (isCircle(pos)) {
        activeGizmo = GIZMO_TYPE.CIRCLE;
        lastPosition = remapPoint(pos);
        script.cursor.setCursor(script.cursor.CursorType.ClosedHand);
        script.controller.onCircleItemMoveStarted();
    }
});

script.createEvent("HoverEvent").bind((eventData) => {
    if (isNull(activeGizmo)) {
        const pos = eventData.getHoverPosition();
        if (script.topLeftSt.containsScreenPoint(pos)) {
            script.cursor.setCursor(script.cursor.CursorType.Scale_v1);
        } else if (script.bottomLeftSt.containsScreenPoint(pos)) {
            script.cursor.setCursor(script.cursor.CursorType.Scale_v2);
        } else if (script.bottomRightSt.containsScreenPoint(pos)) {
            script.cursor.setCursor(script.cursor.CursorType.Scale_v1);
        } else if (script.topRightSt.containsScreenPoint(pos)) {
            script.cursor.setCursor(script.cursor.CursorType.Scale_v2);
        } else if (isCircle(pos)) {
            script.cursor.setCursor(script.cursor.CursorType.OpenHand);
        } else {
            script.cursor.setCursor(script.cursor.CursorType.Default);
        }
    }
});

script.createEvent("TouchMoveEvent").bind((eventData) => {
    if (activeGizmo == null) {
        return;
    }

    const pos = remapPoint(eventData.getTouchPosition());
    const delta = pos.sub(lastPosition);
    delta.y *= -1;

    switch(activeGizmo) {
        case GIZMO_TYPE.BOTTOM_LEFT:
            script.controller.onBottomLeftItemMoved(pos);
        break;
        case GIZMO_TYPE.BOTTOM_RIGHT:
            script.controller.onBottomRightItemMoved(pos);
        break;
        case GIZMO_TYPE.TOP_LEFT:
            script.controller.onTopLeftItemMoved(pos);
        break;
        case GIZMO_TYPE.TOP_RIGHT:
            script.controller.onTopRightItemMoved(pos);
        break;
        case GIZMO_TYPE.CIRCLE:
            script.controller.onCircleItemMoved(delta);
        break;
    }
});

script.createEvent("TouchEndEvent").bind((eventData) => {
    const pos = eventData.getTouchPosition();

    if (script.topLeftSt.containsScreenPoint(pos)) {
        script.cursor.setCursor(script.cursor.CursorType.Scale_v1);
    } else if (script.bottomLeftSt.containsScreenPoint(pos)) {
        script.cursor.setCursor(script.cursor.CursorType.Scale_v2);
    } else if (script.bottomRightSt.containsScreenPoint(pos)) {
        script.cursor.setCursor(script.cursor.CursorType.Scale_v1);
    } else if (script.topRightSt.containsScreenPoint(pos)) {
        script.cursor.setCursor(script.cursor.CursorType.Scale_v2);
    } else if (isCircle(pos)) {
        script.cursor.setCursor(script.cursor.CursorType.OpenHand);
    } else {
        script.cursor.setCursor(script.cursor.CursorType.Default);
    }

    activeGizmo = null;
})
