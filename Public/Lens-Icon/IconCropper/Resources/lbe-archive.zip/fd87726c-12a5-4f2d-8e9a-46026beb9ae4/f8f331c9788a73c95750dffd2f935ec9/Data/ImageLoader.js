// @input Asset.Texture iconCropperRT
// @input Component.Image imagePlaceholder
// @input Asset.Texture viewportRT

// @input SceneObject bottomLeftPivot
// @input SceneObject bottomRightPivot
// @input SceneObject topLeftPivot
// @input SceneObject topRightPivot

// @input Asset.Material fogMaterial
// @input Asset.Material linesMaterial
// @input Asset.Material outputMaterial

// @input SceneObject root
// @input Asset.BinAsset imageExample

// @input Asset.Texture outputCrop
// @input Asset.Texture outputRT

const bottomLeftPivotST = script.bottomLeftPivot.getComponent("Component.ScreenTransform");
const bottomRightPivotST = script.bottomRightPivot.getComponent("Component.ScreenTransform");
const topLeftPivotST = script.topLeftPivot.getComponent("Component.ScreenTransform");
const topRightPivotST = script.topRightPivot.getComponent("Component.ScreenTransform");

const bottomLeftMoveHelper = script.bottomLeftPivot.getComponent("Component.ScriptComponent");
const bottomRightMoveHelper = script.bottomRightPivot.getComponent("Component.ScriptComponent");
const topLeftMoveHelper = script.topLeftPivot.getComponent("Component.ScriptComponent");
const topRightMoveHelper = script.topRightPivot.getComponent("Component.ScriptComponent");

let imageWidth, imageHeight;
let newWidth, newHeight;
let viewportWidth, viewportHeight;
let imageAspectRatio, viewportAspectRatio;
let relativeWidth, relativeHeight;

let imageGeometry, currentGeometry, moveStartGeometry;
let croppingCircle;

script.root.enabled = false;

let currentColor;

let backgroundEnabled;

let imageData;
let pixelsData;

function init(buffer) {
    imageWidth = buffer.control.getWidth();
    imageHeight = buffer.control.getHeight();

    imageData = ProceduralTextureProvider.createFromTexture(buffer);
    pixelsData = new Uint8Array(imageWidth * imageHeight * 4);
    imageData.control.getPixels(0, 0, imageWidth, imageHeight, pixelsData);

    script.fogMaterial.mainPass.size = new vec2(imageWidth, imageHeight);

    script.iconCropperRT.control.resolution = new vec2(imageWidth, imageHeight);

    script.imagePlaceholder.mainPass.baseTex = buffer;
    script.outputCrop.control.inputTexture = buffer;

    viewportWidth = script.viewportRT.control.resolution.x;
    viewportHeight = script.viewportRT.control.resolution.y;

    imageAspectRatio = (imageWidth / imageHeight) ;
    viewportAspectRatio = (viewportWidth / viewportHeight);

    // Fit image to viewport
    if (imageAspectRatio > viewportAspectRatio) {
        // Image is wider than the viewport (relative to height)
        newWidth = viewportWidth;
        newHeight = viewportWidth / imageAspectRatio;
    } else {
        // Image is taller than the viewport (relative to width)
        newHeight = viewportHeight;
        newWidth = viewportHeight * imageAspectRatio;
    }

    // Calculate the relative coordinates in the -1 to 1 range
    relativeWidth = (newWidth / viewportWidth) * 0.95;
    relativeHeight = (newHeight / viewportHeight) * 0.95;

    imageGeometry = {
        left: -relativeWidth,
        top: -relativeHeight,
        right: relativeWidth,
        bottom: relativeHeight
    }

    croppingCircle = {
        center: new vec2(imageWidth / 2, imageHeight / 2),
        radius: Math.min(imageWidth, imageHeight) / 2
    }

    currentGeometry = {
        left: absoluteToRelativePoint(new vec2(croppingCircle.center.x - croppingCircle.radius, croppingCircle.center.y - croppingCircle.radius)).x,
        top: absoluteToRelativePoint(new vec2(croppingCircle.center.x - croppingCircle.radius, croppingCircle.center.y - croppingCircle.radius)).y,
        right: absoluteToRelativePoint(new vec2(croppingCircle.center.x + croppingCircle.radius, croppingCircle.center.y + croppingCircle.radius)).x,
        bottom: absoluteToRelativePoint(new vec2(croppingCircle.center.x + croppingCircle.radius, croppingCircle.center.y + croppingCircle.radius)).y
    }

    moveStartGeometry = {
        left: currentGeometry.left,
        top: currentGeometry.top,
        right: currentGeometry.right,
        bottom: currentGeometry.bottom
    }

    setCropCircle(currentGeometry);
    script.root.enabled = true;

    //setBackground(0, 0, 255);
    //setBackground(currentColor.r, currentColor.g, currentColor.b);
    //setBackground(216,217,219);
}

function reset() {
    currentColor = {
        r: 255,
        g: 255,
        b: 255
    }

    backgroundEnabled = false;

    setBackground(216,217,219);
    script.root.enabled = false;
}

reset();

script.createEvent("MessageEvent").bind((event) => {
    const type = event.data.event_type;

    if (type == "init") {
        Base64.decodeTextureAsync(event.data.image_buffer, (texture) => {
            init(texture)
        }, () => {

        });
    } else if (type == "apply") {
        Base64.encodeTextureAsync(script.outputRT, (encodedTexture) => {
            Editor.context.postMessage({
                "event_type": "apply_texture",
                "encoded_texture": encodedTexture
            });
        }, () => {

        },
        CompressionQuality.MaximumQuality,
        EncodingType.Png);
    } else if (type == "setBackground") {
        currentColor = JSON.parse(event.data.color);
        if (backgroundEnabled) {
            setBackground(currentColor.r, currentColor.g, currentColor.b);
        }
    } else if (type == "enableBackground") {
        backgroundEnabled = event.data.enabled;
        if (backgroundEnabled) {
            setBackground(currentColor.r, currentColor.g, currentColor.b);
        } else {
            setBackground(216,217,219);
        }
    } else if (type == "reset") {
        reset();
        if (event.data.callback_event_type) {

            let message = {
                "event_type": event.data.callback_event_type
            }
            const data = JSON.parse(event.data.callback_event_data);

            for (let key in data) {
                message[key] = data[key];
            }

            Editor.context.postMessage(message);
        }
    } else if (type == "auto_crop") {
        autoCrop();
    }
});

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function autoCrop() {
    const checkColorSimilarity = (c1, c2) => {
        const tolerance = 25;
        const redDistance = Math.abs(c1.r - c2.r);
        const greenDistance = Math.abs(c1.g - c2.g);
        const blueDistance = Math.abs(c1.b - c2.b);
        const alphaDistance = Math.abs(c1.a - c2.a);

        return redDistance < tolerance &&
               greenDistance < tolerance &&
               blueDistance < tolerance &&
               alphaDistance < tolerance &&
               (redDistance + greenDistance + blueDistance + alphaDistance) * 4 <= tolerance * 5;
    }

    const getPixel = (i, j) => {
        const index = Math.floor((j * imageData.getWidth() + i) * 4);
        return new vec4(pixelsData[index], pixelsData[index + 1], pixelsData[index + 2], pixelsData[index + 3]);
    }

    const bgColor = getPixel(0, 0);

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    for (let y = 0; y < imageData.getHeight(); y++) {
        for (let x = 0; x < imageData.getWidth(); x++) {
            // Get the current pixel color
            let pixelColor = getPixel(x, y);
            // Check if the pixel is not similar to the background color
            if (!checkColorSimilarity(pixelColor, bgColor)) {
                // Update the bounding box coordinates
                if (x < minX) minX = x;
                if (y < minY) minY = y;
                if (x > maxX) maxX = x;
                if (y > maxY) maxY = y;
            }
        }
    }
     // Check if no non-background pixels were found
    if (minX === Infinity || minY === Infinity || maxX === -Infinity || maxY === -Infinity) {
        // Return null or an empty box if no non-background pixels were found
        return;
    }

    croppingCircle = {
        center: new vec2((maxX + minX) / 2, (maxY + minY) / 2),
        radius: Math.min((maxX - minX + 1), (maxY - minY + 1)) / 2
    }

    currentGeometry = {
        left: clamp(absoluteToRelativePoint(new vec2(croppingCircle.center.x - croppingCircle.radius, croppingCircle.center.y - croppingCircle.radius)).x, imageGeometry.left, imageGeometry.right),
        top: clamp(absoluteToRelativePoint(new vec2(croppingCircle.center.x - croppingCircle.radius, croppingCircle.center.y - croppingCircle.radius)).y, imageGeometry.top, imageGeometry.bottom),
        right: clamp(absoluteToRelativePoint(new vec2(croppingCircle.center.x + croppingCircle.radius, croppingCircle.center.y + croppingCircle.radius)).x, imageGeometry.left, imageGeometry.right),
        bottom: clamp(absoluteToRelativePoint(new vec2(croppingCircle.center.x + croppingCircle.radius, croppingCircle.center.y + croppingCircle.radius)).y, imageGeometry.top, imageGeometry.bottom)
    }

    moveStartGeometry = {
        left: currentGeometry.left,
        top: currentGeometry.top,
        right: currentGeometry.right,
        bottom: currentGeometry.bottom
    }

    setCropCircle(currentGeometry);
}
/*
Base64.decodeTextureAsync(script.imageExample.readText(), (texture) => {
    init(texture);
    //autoCrop();
}, () => {
    print("Decoding error");
});
*/
function setBackground(r, g, b) {
    script.iconCropperRT.control.clearColor = new vec4(r / 255, g / 255, b / 255, script.iconCropperRT.control.clearColor.w);
    script.outputMaterial.mainPass.background = script.iconCropperRT.control.clearColor;
}

function enableBackground(enabled) {
    const color = script.iconCropperRT.control.clearColor;
    if (enabled) {
        script.iconCropperRT.control.clearColor = new vec4(color.r, color.g, color.b, 1);
        script.outputMaterial.mainPass.background = new vec4(color.r, color.g, color.b, 1);
    } else {
        script.iconCropperRT.control.clearColor = new vec4(color.r, color.g, color.b, 0);
        script.outputMaterial.mainPass.background = new vec4(color.r, color.g, color.b, 0)
    }

}

function absoluteToRelativePoint(pos) {
    return new vec2(
        -relativeWidth + (relativeWidth * 2) * (pos.x / imageWidth),
        -relativeHeight + (relativeHeight * 2) * (pos.y / imageHeight)
    );
}

function relativeToAbsolutePoint(pos) {
    return new vec2(
        imageWidth * remap(imageGeometry.left, imageGeometry.right, 0, 1, pos.x),
        imageHeight * remap(imageGeometry.top, imageGeometry.bottom, 0, 1, pos.y)
    );
}

function remap(a, b, c, d, x) {
    return c + ((x - a) / (b - a)) * (d - c);
}

function setCropCircle(geometry) {
    const imageSize = Math.min(
        remap(0, imageGeometry.right - imageGeometry.left, 0, 1, geometry.right - geometry.left) * imageWidth / 2,
        remap(0, imageGeometry.bottom - imageGeometry.top, 0, 1, geometry.bottom - geometry.top) * imageHeight / 2
    ) * 2;

    if (imageSize < 100) {
        return;
    }

    currentGeometry = geometry;
    croppingCircle.center = relativeToAbsolutePoint(new vec2((geometry.right + geometry.left) / 2, (geometry.bottom + geometry.top) / 2));
    script.fogMaterial.mainPass.center = croppingCircle.center;

    croppingCircle.radius = Math.min(
        remap(0, imageGeometry.right - imageGeometry.left, 0, 1, geometry.right - geometry.left) * imageWidth / 2,
        remap(0, imageGeometry.bottom - imageGeometry.top, 0, 1, geometry.bottom - geometry.top) * imageHeight / 2
    );

    script.outputCrop.control.cropRect = Rect.create(
        remap(imageGeometry.left, imageGeometry.right, -1, 1, geometry.left),
        remap(imageGeometry.left, imageGeometry.right, -1, 1, geometry.right),
        remap(imageGeometry.top, imageGeometry.bottom, -1, 1, geometry.top),
        remap(imageGeometry.top, imageGeometry.bottom, -1, 1, geometry.bottom),
    );

    script.fogMaterial.mainPass.radius = croppingCircle.radius;

    bottomLeftPivotST.anchors.setCenter(new vec2(geometry.left, geometry.bottom));
    bottomRightPivotST.anchors.setCenter(new vec2(geometry.right, geometry.bottom));
    topLeftPivotST.anchors.setCenter(new vec2(geometry.left, geometry.top));
    topRightPivotST.anchors.setCenter(new vec2(geometry.right, geometry.top));

    script.linesMaterial.mainPass.left = geometry.left;
    script.linesMaterial.mainPass.right = geometry.right;
    script.linesMaterial.mainPass.top = geometry.bottom;
    script.linesMaterial.mainPass.bottom = geometry.top;

    /*
    Base64.encodeTextureAsync(script.outputRT, (encodedTexture) => {
        Editor.context.postMessage({
            "event_type": "update_preview",
            "encoded_texture": encodedTexture
        });
    }, () => {

    },
    CompressionQuality.MaximumQuality,
    EncodingType.Png);
    */
}


function calculateTopLeftGeometry(pos) {
    let resultGeometry;

    let vecM = new vec2(pos.x - currentGeometry.right, -pos.y - currentGeometry.bottom);
    let vecA = new vec2(-viewportHeight, -viewportWidth).normalize();

    let proj = vecM.project(vecA);

    let resultPoint = new vec2(currentGeometry.right, currentGeometry.bottom).add(proj);

    resultGeometry = {
        left: resultPoint.x,
        top: resultPoint.y,
        right: currentGeometry.right,
        bottom: currentGeometry.bottom
    }

    if (
        resultGeometry.left >= imageGeometry.left - 0.0001 &&
        resultGeometry.right <= imageGeometry.right + 0.0001 &&
        resultGeometry.top >= imageGeometry.top - 0.0001 &&
        resultGeometry.bottom <= imageGeometry.bottom + 0.0001
    ) {
        setCropCircle(resultGeometry);
    }
}

function calculateBottomLeftGeometry(pos) {
    let resultGeometry;

    let vecM = new vec2(pos.x - currentGeometry.right, -pos.y - currentGeometry.top);
    let vecA = new vec2(-viewportHeight, viewportWidth).normalize();

    let proj = vecM.project(vecA);

    let resultPoint = new vec2(currentGeometry.right, currentGeometry.top).add(proj);

    resultGeometry = {
        left: resultPoint.x,
        top: currentGeometry.top,
        right: currentGeometry.right,
        bottom: resultPoint.y
    }

    if (
        resultGeometry.left >= imageGeometry.left - 0.0001 &&
        resultGeometry.right <= imageGeometry.right + 0.0001 &&
        resultGeometry.top >= imageGeometry.top - 0.0001 &&
        resultGeometry.bottom <= imageGeometry.bottom + 0.0001
    ) {
        setCropCircle(resultGeometry);
    }
}

function calculateTopRightGeometry(pos) {
    let resultGeometry;

    let vecM = new vec2(pos.x - currentGeometry.left, -pos.y - currentGeometry.bottom);
    let vecA = new vec2(viewportHeight, -viewportWidth).normalize();

    let proj = vecM.project(vecA);

    let resultPoint = new vec2(currentGeometry.left, currentGeometry.bottom).add(proj);

    resultGeometry = {
        left: currentGeometry.left,
        top: resultPoint.y,
        right: resultPoint.x,
        bottom: currentGeometry.bottom
    }

    if (
        resultGeometry.left >= imageGeometry.left - 0.0001 &&
        resultGeometry.right <= imageGeometry.right + 0.0001 &&
        resultGeometry.top >= imageGeometry.top - 0.0001 &&
        resultGeometry.bottom <= imageGeometry.bottom + 0.0001
    ) {
        setCropCircle(resultGeometry);
    }
}

function calculateBottomRightGeometry(pos) {
    let resultGeometry;

    let vecM = new vec2(pos.x - currentGeometry.left, -pos.y - currentGeometry.top);
    let vecA = new vec2(viewportHeight, viewportWidth).normalize();

    let proj = vecM.project(vecA);

    let resultPoint = new vec2(currentGeometry.left, currentGeometry.top).add(proj);

    resultGeometry = {
        left: currentGeometry.left,
        top: currentGeometry.top,
        right: resultPoint.x,
        bottom: resultPoint.y
    }

    if (
        resultGeometry.left >= imageGeometry.left - 0.0001 &&
        resultGeometry.right <= imageGeometry.right + 0.0001 &&
        resultGeometry.top >= imageGeometry.top - 0.0001 &&
        resultGeometry.bottom <= imageGeometry.bottom + 0.0001
    ) {
        setCropCircle(resultGeometry);
    }
}

function calculateCircleGeometry(delta) {
    let resultGeometry = {
        left: moveStartGeometry.left + delta.x,
        top: moveStartGeometry.top + delta.y,
        right: moveStartGeometry.right + delta.x,
        bottom: moveStartGeometry.bottom + delta.y
    }

    if (resultGeometry.left <= imageGeometry.left - 0.0001) {
        let delta = imageGeometry.left - resultGeometry.left;

        resultGeometry.right = imageGeometry.left + resultGeometry.right - resultGeometry.left;
        resultGeometry.left = imageGeometry.left;
    }

    if (resultGeometry.right >= imageGeometry.right + 0.0001) {
        let delta = imageGeometry.right - resultGeometry.right;

        resultGeometry.left = imageGeometry.right - resultGeometry.right + resultGeometry.left;
        resultGeometry.right = imageGeometry.right;
    }

    if (resultGeometry.top <= imageGeometry.top - 0.0001) {
        let delta = imageGeometry.top - resultGeometry.top;

        resultGeometry.bottom = imageGeometry.top + resultGeometry.bottom - resultGeometry.top;
        resultGeometry.top = imageGeometry.top;
    }

    if (resultGeometry.bottom >= imageGeometry.bottom + 0.0001) {
        let delta = imageGeometry.bottom - resultGeometry.bottom;

        resultGeometry.top = imageGeometry.bottom - resultGeometry.bottom + resultGeometry.top;
        resultGeometry.bottom = imageGeometry.bottom;
    }

    if (
        resultGeometry.left >= imageGeometry.left - 0.0001 &&
        resultGeometry.right <= imageGeometry.right + 0.0001 &&
        resultGeometry.top >= imageGeometry.top - 0.0001 &&
        resultGeometry.bottom <= imageGeometry.bottom + 0.0001
    ) {
        setCropCircle(resultGeometry);
    }
}

function updateStartMovePosition() {
    moveStartGeometry.left = currentGeometry.left;
    moveStartGeometry.right = currentGeometry.right;
    moveStartGeometry.top = currentGeometry.top;
    moveStartGeometry.bottom = currentGeometry.bottom;
}

script.onTopLeftItemMoved = (delta) => {
    calculateTopLeftGeometry(delta);
};
script.onBottomLeftItemMoved = (delta) => {
    calculateBottomLeftGeometry(delta);
};
script.onTopRightItemMoved = (delta) => {
    calculateTopRightGeometry(delta);
};
script.onBottomRightItemMoved = (delta) => {
    calculateBottomRightGeometry(delta);
};

script.onCircleItemMoveStarted = () => {
    updateStartMovePosition();
}

script.onCircleItemMoved = (delta) => {
    calculateCircleGeometry(delta);
}
